<template>
  <aside class="sidebar" :class="{ 'sidebar-open': isOpen }">
    <div class="sidebar-mobile-bar">
      <div class="logo" style="margin-bottom: 0;">
        <img :src="isDarkMode ? '/logo%20dark.png' : '/logo.png'" alt="Madinaty logo" />
        <div class="sidebar-brand-text">
          <strong>{{ t('nav', 'adminWorkspace') }}</strong>
          <span>{{ t('nav', 'operationsControlCenter') }}</span>
        </div>
      </div>

      <button type="button" class="sidebar-close-btn" @click="$emit('close')" :aria-label="t('nav', 'closeNavigation')">
        <i class="fas fa-xmark"></i>
      </button>
    </div>

    <div class="logo sidebar-desktop-logo">
      <img :src="isDarkMode ? '/logo%20dark.png' : '/logo.png'" alt="Madinaty logo" />
      <div class="sidebar-brand-text">
        <strong>{{ t('nav', 'adminWorkspace') }}</strong>
        <span>{{ t('nav', 'operationsControlCenter') }}</span>
      </div>
    </div>

    <ul>
      <li v-for="item in navItems" :key="item.name" :class="{ active: $route.name === item.name }">
        <RouterLink :to="item.to" @click="$emit('close')">
          <i :class="item.icon"></i>
          <span>{{ item.label() }}</span>
        </RouterLink>
      </li>
    </ul>

    <div class="sidebar-footer">
      {{ t('nav', 'operationsControlCenter') }}
    </div>
  </aside>
</template>

<script setup>
import { t } from '../utils/i18n'

defineProps({
  isOpen: {
    type: Boolean,
    default: false,
  },
  isDarkMode: {
    type: Boolean,
    default: false,
  },
})

defineEmits(['close'])

const navItems = [
  { name: 'Dashboard', label: () => t('common', 'dashboard'), to: '/', icon: 'fas fa-chart-line' },
  { name: 'Reports', label: () => t('common', 'reports'), to: '/reports', icon: 'fas fa-triangle-exclamation' },
  { name: 'News', label: () => t('common', 'news'), to: '/news', icon: 'fas fa-bullhorn' },
  { name: 'Categories', label: () => t('common', 'categories'), to: '/categories', icon: 'fas fa-layer-group' },
  { name: 'MyView', label: () => t('common', 'myView'), to: '/myview', icon: 'fas fa-map-location-dot' },
  { name: 'Users', label: () => t('common', 'users'), to: '/users', icon: 'fas fa-users-gear' },
  { name: 'Settings', label: () => t('common', 'settings'), to: '/settings', icon: 'fas fa-sliders' },
]
</script>
