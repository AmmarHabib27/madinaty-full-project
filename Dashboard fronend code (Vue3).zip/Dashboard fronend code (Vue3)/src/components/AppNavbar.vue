<template>
  <nav class="navbar-custom">
    <div class="navbar-main">
      <button
        type="button"
        class="mobile-menu-btn"
        :aria-expanded="isSidebarOpen ? 'true' : 'false'"
        :aria-label="t('nav', 'toggleNavigation')"
        @click="$emit('toggle-sidebar')"
      >
        <i :class="isSidebarOpen ? 'fas fa-xmark' : 'fas fa-bars'"></i>
      </button>

      <div class="navbar-meta">
        <span class="navbar-eyebrow">{{ t('nav', 'managementSystem') }}</span>
        <strong class="navbar-title">{{ t('nav', 'adminWorkspace') }}</strong>
      </div>
    </div>

    <div class="navbar-actions">
      <button
        type="button"
        class="nav-icon-btn theme-toggle-btn"
        :class="{ active: isDarkMode }"
        :aria-label="isDarkMode ? t('nav', 'switchToLight') : t('nav', 'switchToDark')"
        :aria-pressed="isDarkMode ? 'true' : 'false'"
        :title="isDarkMode ? t('nav', 'switchToLight') : t('nav', 'switchToDark')"
        @click="$emit('toggle-theme')"
      >
        <i :class="isDarkMode ? 'fas fa-sun' : 'fas fa-moon'"></i>
      </button>

      <button
        type="button"
        class="nav-icon-btn language-toggle-btn"
        @click="toggleLanguage"
      >
        {{ currentLocale === 'ar' ? 'EN' : 'ع' }}
      </button>

      <div class="user-profile-dropdown" ref="dropdownRef">
        <button type="button" class="user-chip" @click="dropdownOpen = !dropdownOpen">
          <img :src="profileImage" alt="User Avatar" class="user-avatar" @error="usePlaceholderImage" />
          <div class="user-chip-text">
            <strong>{{ profileName }}</strong>
            <span>{{ profileEmail }}</span>
          </div>
          <i class="fas fa-chevron-down"></i>
        </button>

        <Transition name="profile-menu">
          <ul v-if="dropdownOpen" class="profile-dropdown-menu">
            <li>
              <div class="profile-info">
                <strong>{{ profileName }}</strong>
                <small>{{ profileEmail }}</small>
              </div>
            </li>
            <li><hr class="dropdown-divider" /></li>
            <li>
              <RouterLink class="dropdown-item" to="/settings" @click="dropdownOpen = false">
                <i class="fas fa-user-circle"></i>
                {{ t('nav', 'profileSettings') }}
              </RouterLink>
            </li>
            <li>
              <button class="dropdown-item" type="button" @click="handleChangePassword">
                <i class="fas fa-key"></i>
                {{ t('nav', 'changePassword') }}
              </button>
            </li>
            <li><hr class="dropdown-divider" /></li>
            <li>
              <button class="dropdown-item logout-item" type="button" @click="handleLogout">
                <i class="fas fa-sign-out-alt"></i>
                {{ t('nav', 'logout') }}
              </button>
            </li>
          </ul>
        </Transition>
      </div>
    </div>
  </nav>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'
import { useProfileStore } from '../stores/profile'
import { DEFAULT_PROFILE_IMAGE } from '../utils/mediaHelper'
import { getLocale, isArabic, setLocale, t, useLocale } from '../utils/i18n'

defineProps({
  isSidebarOpen: {
    type: Boolean,
    default: false,
  },
  isDarkMode: {
    type: Boolean,
    default: false,
  },
})

defineEmits(['toggle-sidebar', 'toggle-theme'])

const router = useRouter()
const authStore = useAuthStore()
const profileStore = useProfileStore()
const dropdownOpen = ref(false)
const dropdownRef = ref(null)
const currentLocale = useLocale()

const profileName = computed(() => profileStore.profile?.name || t('common', 'unknownUser'))
const profileEmail = computed(() => profileStore.profile?.email || 'admin@madinaty.com')
const profileImage = computed(() => profileStore.profileImage || DEFAULT_PROFILE_IMAGE)

function toggleLanguage() {
  setLocale(currentLocale.value === 'ar' ? 'en' : 'ar')
}

function usePlaceholderImage(event) {
  if (event.target.src.endsWith(DEFAULT_PROFILE_IMAGE)) return
  event.target.src = DEFAULT_PROFILE_IMAGE
}

function handleClickOutside(event) {
  if (dropdownRef.value && !dropdownRef.value.contains(event.target)) {
    dropdownOpen.value = false
  }
}

async function handleLogout() {
  try {
    await authStore.logout()
  } finally {
    dropdownOpen.value = false
    await router.push('/login')
  }
}

function handleChangePassword() {
  dropdownOpen.value = false
  router.push({ name: 'Settings', query: { tab: 'password' } })
}

onMounted(() => {
  document.addEventListener('click', handleClickOutside)
  if (!profileStore.profile) {
    profileStore.fetchProfile().catch(() => {})
  }
})
onUnmounted(() => document.removeEventListener('click', handleClickOutside))
</script>

<style scoped>
.profile-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 10px 12px;
}

.profile-info small {
  color: var(--text-soft);
}

.logout-item {
  color: var(--danger);
}
</style>
