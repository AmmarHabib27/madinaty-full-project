<template>
  <div class="reports-view">
    <div class="topbar">
      <div class="page-intro">
        <span class="eyebrow"><i class="fas fa-triangle-exclamation"></i> {{ t('complaints', 'complaintPage') }}</span>
        <h2 class="page-title">{{ t('complaints', 'browseComplaints') }}</h2>
        <p class="page-subtitle">{{ t('complaints', 'filtersStayHere') }}</p>
      </div>

      <div class="topbar-actions">
        <button class="btn-reports" type="button" @click="showFilter = !showFilter">
          <i class="fas fa-filter"></i>
          {{ showFilter ? t('complaints', 'hideFilters') : t('complaints', 'filterComplaints') }}
        </button>
        <button class="btn-secondary" type="button" @click="loadComplaints" :disabled="loading">
          <i class="fas fa-rotate-right"></i>
          {{ t('common', 'refresh') }}
        </button>
      </div>
    </div>

  <div v-if="fetchError" class="error-message">
    <i class="fas fa-circle-exclamation"></i>
    <span>{{ fetchError }}</span>
  </div>

  <div v-if="showFilter" class="page-panel" style="margin-bottom: 18px;">
    <div class="card-head">
      <div>
        <span class="eyebrow">{{ t('common', 'filters') }}</span>
        <h3>{{ t('common', 'refineList') }}</h3>
      </div>
      <span class="pill">{{ t('common', 'liveQuery') }}</span>
    </div>

    <form class="filter-form" @submit.prevent="applyFilter">
      <div class="filter-row">
        <div class="filter-group">
          <label>{{ t('common', 'status') }}</label>
          <select v-model="filter.status">
            <option value="">{{ t('complaints', 'allStatuses') }}</option>
            <option value="placed">{{ formatStatusLabel('placed') }}</option>
            <option value="in_progress">{{ formatStatusLabel('in_progress') }}</option>
            <option value="resolved">{{ formatStatusLabel('resolved') }}</option>
          </select>
        </div>
        <div class="filter-group">
          <label>{{ t('common', 'priority') }}</label>
          <select v-model="filter.priority">
            <option value="">{{ t('complaints', 'allPriorities') }}</option>
            <option value="low">{{ t('map', 'low') }}</option>
            <option value="medium">{{ t('map', 'intermediate') }}</option>
            <option value="high">{{ t('map', 'high') }}</option>
          </select>
        </div>
      </div>

      <div class="filter-row">
        <div class="filter-group">
          <label>{{ t('common', 'category') }}</label>
          <input v-model="filter.category" type="text" :placeholder="t('complaints', 'categoryPlaceholder')" />
        </div>
        <div class="filter-group">
          <label>{{ t('common', 'user') }}</label>
          <input v-model="filter.user_name" type="text" :placeholder="t('complaints', 'userNamePlaceholder')" />
        </div>
      </div>

      <div class="filter-group">
        <label>{{ t('common', 'search') }}</label>
        <input v-model="filter.search" type="text" :placeholder="t('complaints', 'searchPlaceholder')" />
      </div>

      <div class="form-actions">
        <button type="submit" class="button-submit">{{ t('common', 'apply') }}</button>
        <button type="button" class="btn-cancel" @click="resetFilters">{{ t('common', 'reset') }}</button>
      </div>
    </form>
  </div>

  <div class="table-shell">
    <div class="table-toolbar">
      <div class="card-head">
        <div>
          <h3 class="table-title">{{ t('complaints', 'complaintQueue') }}</h3>
          <p class="muted-text">{{ t('complaints', 'openReport') }}</p>
        </div>
        <span class="pill">{{ t('complaints', 'visibleCount', { count: complaints.length }) }}</span>
      </div>
    </div>

    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            <th>{{ t('common', 'id') }}</th>
            <th>{{ t('common', 'title') }}</th>
            <th>{{ t('common', 'status') }}</th>
            <th>{{ t('common', 'priority') }}</th>
            <th>{{ t('common', 'user') }}</th>
            <th>{{ t('common', 'category') }}</th>
            <th>{{ t('common', 'created') }}</th>
            <th>{{ t('common', 'actions') }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="loading">
            <td colspan="8">{{ t('complaints', 'loadingComplaint') }}</td>
            </tr>
          <tr v-else-if="complaints.length === 0">
            <td colspan="8">{{ t('complaints', 'noComplaints') }}</td>
          </tr>
          <tr v-for="complaint in complaints" :key="complaint.id">
            <td data-label="ID">#{{ complaint.id }}</td>
            <td data-label="Title">
              <strong>{{ complaint.title }}</strong>
              <div class="muted-text">{{ trimText(complaint.description) }}</div>
            </td>
            <td data-label="Status"><span class="status-pill" :class="statusClass(complaint.status)">{{ formatStatus(complaint.status) }}</span></td>
            <td data-label="Priority"><span class="status-pill warning">{{ formatPriority(complaint.priority) }}</span></td>
            <td data-label="User">{{ complaint.user_name || t('common', 'unknownUser') }}</td>
            <td data-label="Category">{{ complaint.category_name || t('common', 'uncategorized') }}</td>
            <td data-label="Created">{{ formatDate(complaint.created_at) }}</td>
            <td data-label="Action">
              <div class="action-buttons">
                <RouterLink class="btn-view" :to="{ name: 'ReportDetails', params: { id: complaint.id } }">{{ t('common', 'open') }}</RouterLink>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="page-panel" style="margin: 20px 0 0;">
    <div class="card-head">
      <div>
        <span class="eyebrow">{{ t('map', 'map') }}</span>
        <h3>{{ t('complaints', 'mapTitle') }}</h3>
      </div>
      <span class="pill">{{ t('complaints', 'clickPin') }}</span>
    </div>
    <div id="complaints-map" class="complaints-map"></div>
  </div>

  <div class="pagination-controls" v-if="pagination.previous || pagination.next || totalPages">
    <button class="btn-secondary" type="button" :disabled="!pagination.previous || loading" @click="changePage(currentPage - 1)">
      {{ t('users', 'previous') }}
    </button>
    <span class="page-summary">
      {{ t('common', 'page') }} {{ currentPage }}
      <span v-if="totalPages"> {{ t('common', 'pageOf') }} {{ totalPages }}</span>
    </span>
    <button class="btn-secondary" type="button" :disabled="!pagination.next || loading" @click="changePage(currentPage + 1)">
      {{ t('users', 'next') }}
    </button>
  </div>
</div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { complaintsApi } from '../api/complaints'
import { loadLeafletAssets } from '../utils/leafletLoader'
import { t, formatStatusLabel, formatPriorityLabel } from '../utils/i18n'

const router = useRouter()
const loading = ref(false)
const complaints = ref([])
const pagination = ref({})
const currentPage = ref(1)
const showFilter = ref(false)
const fetchError = ref('')
const mapLoaded = ref(false)
const mapInstance = ref(null)
const markerLayer = ref(null)

const filter = ref({
  status: '',
  priority: '',
  category: '',
  user_name: '',
  search: '',
})

const totalPages = computed(() => {
  if (!pagination.value.count) return null
  const pageSize = pagination.value.page_size || complaints.value.length || 1
  return Math.ceil(pagination.value.count / pageSize)
})

function buildParams(page = 1) {
  const params = { page }
  if (filter.value.status) params.status = filter.value.status
  if (filter.value.priority) params.priority = filter.value.priority
  if (filter.value.category) params.category = filter.value.category
  if (filter.value.user_name) params.user_name = filter.value.user_name
  if (filter.value.search) params.search = filter.value.search
  return params
}

async function initMap() {
  if (mapLoaded.value) return
  try {
    await loadLeafletAssets()
  } catch (error) {
    fetchError.value = t('complaints', 'unableLoadMap')
    return
  }

  mapInstance.value = window.L.map('complaints-map', {
    center: [31.45, 31.66],
    zoom: 12,
    scrollWheelZoom: false,
  })

  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors',
    maxZoom: 18,
  }).addTo(mapInstance.value)

  markerLayer.value = window.L.layerGroup().addTo(mapInstance.value)
  mapLoaded.value = true
  updateMapMarkers()
}

function updateMapMarkers() {
  if (!mapLoaded.value || !markerLayer.value) return
  markerLayer.value.clearLayers()

  const validMarkers = []
  complaints.value.forEach((complaint) => {
    const lat = parseFloat(complaint.latitude)
    const lng = parseFloat(complaint.longitude)
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return

    const marker = window.L.marker([lat, lng]).addTo(markerLayer.value)
    marker.bindTooltip(`${t('common', 'report')} #${complaint.id}: ${complaint.title}`, {
      direction: 'top',
      opacity: 0.95,
    })
    marker.on('click', () => {
      router.push({ name: 'ReportDetails', params: { id: complaint.id } })
    })
    validMarkers.push(marker)
  })

  if (validMarkers.length > 0) {
    const group = window.L.featureGroup(validMarkers)
    mapInstance.value.fitBounds(group.getBounds().pad(0.2))
  }
}

async function fetchComplaints(page = 1) {
  loading.value = true
  fetchError.value = ''

  try {
    currentPage.value = page
    const response = await complaintsApi.getAll(buildParams(page))
    complaints.value = response.data.data || []
    pagination.value = response.data.pagination || {}
  } catch (error) {
    fetchError.value = t('complaints', 'unableLoadComplaints')
  } finally {
    loading.value = false
  }

  if (!mapLoaded.value && document.getElementById('complaints-map')) {
    await initMap()
  } else {
    updateMapMarkers()
  }
}

async function loadComplaints() {
  await fetchComplaints(currentPage.value)
}

function changePage(page) {
  if (page < 1) return
  fetchComplaints(page)
}

function applyFilter() {
  showFilter.value = false
  fetchComplaints(1)
}

function resetFilters() {
  filter.value = {
    status: '',
    priority: '',
    category: '',
    user_name: '',
    search: '',
  }
  fetchComplaints(1)
}

function formatDate(value) {
  if (!value) return t('common', 'na')
  return new Date(value).toLocaleString()
}

function formatStatus(value) {
  if (!value) return t('common', 'unknown')
  return formatStatusLabel(value)
}

function formatPriority(value) {
  if (!value) return t('common', 'unknown')
  return formatPriorityLabel(value)
}

function statusClass(status) {
  if (status === 'resolved') return 'success'
  if (status === 'in_progress') return 'warning'
  return ''
}

function trimText(text) {
  if (!text) return t('complaints', 'noDescription')
  return text.length > 72 ? `${text.slice(0, 72)}...` : text
}

onMounted(() => fetchComplaints(1))
</script>
