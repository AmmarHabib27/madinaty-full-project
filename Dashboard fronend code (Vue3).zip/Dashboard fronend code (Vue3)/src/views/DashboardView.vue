<template>
  <div class="dashboard-view">
    <div class="topbar">
      <div class="page-intro">
        <span class="eyebrow"><i class="fas fa-sparkles"></i> {{ t('dashboard', 'dailySnapshot') }}</span>
        <h1 class="page-title">{{ t('dashboard', 'seeWhatNeedsAction') }}</h1>
        <p class="page-subtitle">
          {{ t('dashboard', 'trackComplaintMovement') }}
        </p>
      </div>

      <div class="stack-actions">
        <span class="status-pill success"><i class="fas fa-circle"></i> {{ t('dashboard', 'operationsOnline') }}</span>
        <button class="btn-secondary" type="button" :disabled="loadingStats" @click="store.fetchDashboardStats">
          <i class="fas fa-rotate-right"></i>
          {{ loadingStats ? t('dashboard', 'refreshing') : t('dashboard', 'refreshStats') }}
        </button>
      </div>
    </div>

  <div v-if="statsError" class="error-message">
    <i class="fas fa-circle-exclamation"></i>
    <span>{{ statsError }}</span>
  </div>

  <div class="cards-wrapper">
    <div class="stat-card new">
      <div class="stat-card-header">
        <h4 class="stat-card-title">{{ t('dashboard', 'placedReports') }}</h4>
        <span class="stat-card-icon"><i class="fas fa-file-circle-plus"></i></span>
      </div>
      <h2 class="stat-card-number">{{ formatNumber(stats.new) }}</h2>
      <div class="stat-card-footer">
        <i class="fas fa-list-check"></i>
        <span>{{ t('dashboard', 'waitingFirstReview') }}</span>
      </div>
    </div>

    <div class="stat-card solved">
      <div class="stat-card-header">
        <h4 class="stat-card-title">{{ t('dashboard', 'resolvedReports') }}</h4>
        <span class="stat-card-icon"><i class="fas fa-circle-check"></i></span>
      </div>
      <h2 class="stat-card-number">{{ formatNumber(stats.solved) }}</h2>
      <div class="stat-card-footer">
        <i class="fas fa-check-double"></i>
        <span>{{ t('dashboard', 'closedTeam') }}</span>
      </div>
    </div>

    <div class="stat-card cancelled">
      <div class="stat-card-header">
        <h4 class="stat-card-title">{{ t('dashboard', 'rejectedReports') }}</h4>
        <span class="stat-card-icon"><i class="fas fa-circle-xmark"></i></span>
      </div>
      <h2 class="stat-card-number">{{ formatNumber(stats.cancelled) }}</h2>
      <div class="stat-card-footer">
        <i class="fas fa-ban"></i>
        <span>{{ t('dashboard', 'closedWithoutAction') }}</span>
      </div>
    </div>

    <div class="stat-card latest">
      <div class="stat-card-header">
        <h4 class="stat-card-title">{{ t('dashboard', 'totalReports') }}</h4>
        <span class="stat-card-icon"><i class="fas fa-clock-rotate-left"></i></span>
      </div>
      <h2 class="stat-card-number">{{ formatNumber(stats.latest) }}</h2>
      <div class="stat-card-footer">
        <i class="fas fa-bolt"></i>
        <span>{{ t('dashboard', 'complaintQueueSize') }}</span>
      </div>
    </div>
  </div>

  <div class="insights-grid">
    <section class="insight-card">
      <div class="card-head">
        <div>
          <span class="eyebrow">{{ t('dashboard', 'momentum') }}</span>
          <h3>{{ t('dashboard', 'servicePulse') }}</h3>
        </div>
        <span class="pill">{{ t('common', 'today') }}</span>
      </div>
      <p class="page-subtitle">{{ t('dashboard', 'servicePulse') }}</p>
      <div class="kpi-row">
        <span class="kpi-chip"><i class="fas fa-road"></i> {{ t('dashboard', 'roadsLeadingResolution') }}</span>
        <span class="kpi-chip"><i class="fas fa-tree"></i> {{ t('dashboard', 'landscapingVolumeSteady') }}</span>
      </div>
    </section>

    <section class="insight-card">
      <div class="card-head">
        <div>
          <span class="eyebrow">{{ t('dashboard', 'attentionNeeded') }}</span>
          <h3>{{ t('dashboard', 'areasToWatch') }}</h3>
        </div>
        <span class="pill">{{ t('common', 'live') }}</span>
      </div>
      <p class="page-subtitle">{{ t('dashboard', 'areasToWatch') }}</p>
      <div class="kpi-row">
        <span class="status-pill warning"><i class="fas fa-hourglass-half"></i> {{ t('dashboard', 'pendingFollowUp') }}</span>
        <span class="status-pill"><i class="fas fa-comment-dots"></i> {{ t('dashboard', 'addClearerNotes') }}</span>
      </div>
    </section>
  </div>
</div>
</template>

<script setup>
import { onMounted } from 'vue'
import { storeToRefs } from 'pinia'
import { useReportsStore } from '../stores/reports'
import { t } from '../utils/i18n'

const store = useReportsStore()
const { stats, loadingStats, statsError } = storeToRefs(store)

function formatNumber(value) {
  return Number(value || 0).toLocaleString()
}

onMounted(() => {
  store.fetchDashboardStats()
})
</script>
