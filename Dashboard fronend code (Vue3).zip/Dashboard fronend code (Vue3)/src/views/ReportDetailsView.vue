<template>
  <div class="report-details-view">
    <div class="topbar">
      <div class="page-intro">
        <span class="eyebrow"><i class="fas fa-file-lines"></i> {{ t('complaints', 'complaintPage') }}</span>
      <h2 class="page-title">{{ complaint ? complaint.title : `Complaint #${route.params.id}` }}</h2>
      <p class="page-subtitle">{{ t('complaints', 'filtersStayHere') }}</p>
    </div>

    <div class="topbar-actions">
      <RouterLink class="btn-secondary" :to="{ name: 'Reports' }">
        <i class="fas fa-arrow-left"></i>
        {{ t('common', 'back') }}
      </RouterLink>
    </div>
  </div>

  <div v-if="loading" class="empty-state">
    <h3>{{ t('complaints', 'loadingComplaint') }}</h3>
  </div>

  <div v-else-if="fetchError" class="error-message">
    <i class="fas fa-circle-exclamation"></i>
    <span>{{ fetchError }}</span>
  </div>

  <template v-else-if="complaint">
    <div class="hero-banner">
      <div>
        <span class="status-pill" :class="statusClass(editForm.status)">{{ formatStatus(editForm.status) }}</span>
        <h3 style="margin: 14px 0 8px;">{{ t('common', 'report') }} #{{ complaint.id }}</h3>
        <p class="muted-text" style="margin: 0;">{{ t('complaints', 'createdAndUpdated', { created: formatDate(complaint.created_at), updated: formatDate(complaint.updated_at) }) }}</p>
      </div>
      <div class="hero-banner-tags">
        <span class="pill">{{ complaint.category_name || t('common', 'category') }}</span>
        <span class="pill">{{ complaint.user_name || t('common', 'user') }}</span>
      </div>
    </div>

    <div class="details-page-grid">
      <section class="detail-card">
        <div class="card-head">
          <div>
            <span class="eyebrow">{{ t('common', 'overview') }}</span>
            <h3>{{ t('complaints', 'complaintInfo') }}</h3>
          </div>
        </div>

        <div class="detail-list">
          <div class="detail-row">
            <label>{{ t('common', 'title') }}</label>
            <span>{{ complaint.title }}</span>
          </div>
          <div class="detail-row">
            <label>{{ t('common', 'body') }}</label>
            <span>{{ complaint.description || t('complaints', 'noDescription') }}</span>
          </div>
          <div class="detail-row">
            <label>{{ t('common', 'category') }}</label>
            <span>{{ complaint.category_name || t('common', 'category') }}</span>
          </div>
          <div class="detail-row">
            <label>{{ t('common', 'user') }}</label>
            <span>{{ complaint.user_name || t('common', 'unknown') }} {{ complaint.user_phone ? `(${complaint.user_phone})` : '' }}</span>
          </div>
          <div class="detail-row">
            <label>{{ t('common', 'location') }}</label>
            <span>{{ complaint.location_address || t('complaints', 'noAddress') }}</span>
          </div>
          <div class="detail-row">
            <label>{{ t('common', 'location') }}</label>
            <span>{{ complaint.latitude || '-' }}, {{ complaint.longitude || '-' }}</span>
          </div>
          <div v-if="complaintImages.length" class="detail-row media-detail-row">
            <label>{{ t('common', 'image') }}</label>
            <div class="complaint-media-grid">
              <button
                v-for="(url, idx) in complaintImages"
                :key="idx"
                type="button"
                class="media-thumb-btn"
                @click="openViewer(idx)"
              >
                <img
                  :src="url"
                  :alt="`Complaint image ${idx + 1}`"
                  class="media-thumb"
                />
                <span class="media-thumb-overlay">
                  <i class="fas fa-magnifying-glass-plus"></i>
                </span>
              </button>
            </div>
          </div>
        </div>
      </section>

      <section class="detail-card">
        <div class="card-head">
          <div>
            <span class="eyebrow">{{ t('common', 'editSection') }}</span>
            <h3>{{ t('complaints', 'updateComplaint') }}</h3>
          </div>
        </div>

        <div v-if="editError" class="error-message">
          <i class="fas fa-circle-exclamation"></i>
          <span>{{ editError }}</span>
        </div>
        <div v-if="editSuccess" class="success-message">
          <i class="fas fa-circle-check"></i>
          <span>{{ editSuccess }}</span>
        </div>

        <form class="edit-form" @submit.prevent="updateComplaint">
          <div class="form-row">
            <div class="form-group">
              <label>{{ t('common', 'status') }}</label>
              <select v-model="editForm.status" required>
                <option v-for="status in statusOptions" :key="status" :value="status">{{ formatStatus(status) }}</option>
              </select>
            </div>
            <div class="form-group">
              <label>{{ t('common', 'priority') }}</label>
              <select v-model="editForm.priority" required>
                <option v-for="priority in priorityOptions" :key="priority" :value="priority">{{ formatPriority(priority) }}</option>
              </select>
            </div>
          </div>

          <div class="form-group">
            <label>{{ t('complaints', 'adminComment') }}</label>
            <textarea v-model="editForm.admin_comment" rows="6" :placeholder="t('complaints', 'adminCommentPlaceholder')"></textarea>
          </div>

          <div class="form-actions">
            <button type="submit" class="button-submit" :disabled="savingComplaint">
              {{ savingComplaint ? t('common', 'loading') : t('common', 'save') }}
            </button>
            <button type="button" class="btn-cancel" @click="resetForm">{{ t('common', 'reset') }}</button>
          </div>
        </form>
      </section>
    </div>

    <section class="detail-card">
      <div class="card-head">
        <div>
          <span class="eyebrow">{{ t('map', 'map') }}</span>
          <h3>{{ t('complaints', 'mapOverview') }}</h3>
        </div>
      </div>

      <div id="single-report-map" class="myview-map" style="margin-top: 12px; cursor: pointer;">
        <div v-if="!hasCoordinates" style="padding: 20px; text-align: center; color: var(--text-soft);">
          {{ t('complaints', 'locationNotAvailable') }}
        </div>
      </div>
    </section>

    <Teleport to="body">
      <Transition name="viewer">
        <div
          v-if="activeImageIndex !== null"
          class="img-viewer-backdrop"
          @click.self="closeViewer"
          @keydown.esc="closeViewer"
          tabindex="-1"
          ref="viewerBackdrop"
        >
          <div class="img-viewer-shell">

            <!-- Header bar -->
            <div class="img-viewer-bar">
              <span class="img-viewer-counter" v-if="complaintImages.length > 1">
                <i class="fas fa-images"></i> {{ activeImageIndex + 1 }} / {{ complaintImages.length }}
              </span>
              <span v-else class="img-viewer-counter">
                <i class="fas fa-image"></i> {{ t('common', 'imagePreview') }}
              </span>
              <button type="button" class="img-viewer-close-btn" @click="closeViewer">
                <i class="fas fa-xmark"></i>
              </button>
            </div>

            <!-- Image -->
            <div class="img-viewer-stage">
              <button
                v-if="complaintImages.length > 1"
                type="button"
                class="img-viewer-nav img-viewer-nav--prev"
                @click="prevImage"
              >
                <i class="fas fa-chevron-left"></i>
              </button>

              <Transition name="img-swap" mode="out-in">
                <img
                  :key="activeImageIndex"
                  :src="complaintImages[activeImageIndex]"
                  :alt="`Complaint image ${activeImageIndex + 1}`"
                  class="img-viewer-img"
                />
              </Transition>

              <button
                v-if="complaintImages.length > 1"
                type="button"
                class="img-viewer-nav img-viewer-nav--next"
                @click="nextImage"
              >
                <i class="fas fa-chevron-right"></i>
              </button>
            </div>

            <!-- Dot strip for multiple images -->
            <div v-if="complaintImages.length > 1" class="img-viewer-dots">
              <button
                v-for="(_, i) in complaintImages"
                :key="i"
                type="button"
                class="img-viewer-dot"
                :class="{ active: i === activeImageIndex }"
                @click="activeImageIndex = i"
              />
            </div>

          </div>
        </div>
      </Transition>
    </Teleport>

  </template>
  </div>
</template>

<script setup>
import { onMounted, onUnmounted, ref, nextTick, computed, watch } from 'vue'
import { useRoute } from 'vue-router'
import { complaintsApi } from '../api/complaints'
import { loadLeafletAssets } from '../utils/leafletLoader'
import { normalizeMediaUrl } from '../utils/mediaHelper'
import { t, formatStatusLabel, formatPriorityLabel } from '../utils/i18n'

const route = useRoute()
const loading = ref(false)
const savingComplaint = ref(false)
const complaint = ref(null)
const fetchError = ref('')
const editError = ref('')
const editSuccess = ref('')

const mapLoaded = ref(false)
const mapInstance = ref(null)
const activeImageIndex = ref(null)
const viewerBackdrop = ref(null)

const complaintImages = computed(() => {
  const media = complaint.value?.media
  if (!Array.isArray(media)) return []
  return media
    .filter(m => m.media_type === 'image')
    .map(m => normalizeMediaUrl(m.file))
    .filter(Boolean)
})

function openViewer(idx) {
  activeImageIndex.value = idx
  nextTick(() => viewerBackdrop.value?.focus())
}

function closeViewer() {
  activeImageIndex.value = null
}

function prevImage() {
  if (activeImageIndex.value === null) return
  const total = complaintImages.value.length
  activeImageIndex.value = (activeImageIndex.value - 1 + total) % total
}

function nextImage() {
  if (activeImageIndex.value === null) return
  const total = complaintImages.value.length
  activeImageIndex.value = (activeImageIndex.value + 1) % total
}

function handleKeydown(e) {
  if (activeImageIndex.value === null) return
  if (e.key === 'Escape') closeViewer()
  if (e.key === 'ArrowRight') nextImage()
  if (e.key === 'ArrowLeft') prevImage()
}

onUnmounted(() => window.removeEventListener('keydown', handleKeydown))

const hasCoordinates = computed(() => {
  if (!complaint.value) return false
  const lat = parseFloat(complaint.value.latitude)
  const lng = parseFloat(complaint.value.longitude)
  return Number.isFinite(lat) && Number.isFinite(lng)
})

const editForm = ref({
  status: 'placed',
  priority: 'low',
  admin_comment: '',
})

const statusOptions = ['placed', 'valid', 'on_hold', 'rejected', 'resolved']
const priorityOptions = ['low', 'intermediate', 'high']

function normalizeChoiceValue(value, allowedValues, fallback) {
  if (value === null || value === undefined || value === '') return fallback

  const raw = String(value).trim().toLowerCase()
  const normalized = raw.replace(/[-\s]+/g, '_')

  if (allowedValues.includes(normalized)) return normalized

  const aliasMap = {
    medium: 'intermediate',
    in_progress: 'on_hold',
    'in progress': 'on_hold',
    'on hold': 'on_hold',
    'high priority': 'high',
    'low priority': 'low',
  }

  return aliasMap[normalized] || fallback
}

function normalizeComplaintPayload(payload) {
  if (!payload || typeof payload !== 'object') return {}

  return {
    ...payload,
    status: normalizeChoiceValue(payload.status, statusOptions, 'placed'),
    priority: normalizeChoiceValue(payload.priority, priorityOptions, 'low'),
  }
}

function formatDate(value) {
  if (!value) return t('common', 'na')
  return new Date(value).toLocaleString()
}

function formatStatus(value) {
  if (!value) return t('common', 'unknown')
  return formatStatusLabel(value)
}

function formatPriority(value) {
  if (!value) return t('common', 'unknown')
  return formatPriorityLabel(value)
}

function statusClass(status) {
  if (status === 'resolved') return 'success'
  if (status === 'valid') return 'warning'
  if (status === 'on_hold') return 'warning'
  if (status === 'rejected') return 'danger'
  return ''
}

function parseError(error) {
  const errorData = error.response?.data
  if (!errorData) return t('common', 'unexpectedError')
  if (typeof errorData === 'string') return errorData

  if (errorData.data && typeof errorData.data === 'object') {
    const fields = Object.keys(errorData.data)
    if (fields.length > 0) {
      const firstFieldErrors = errorData.data[fields[0]]
      if (Array.isArray(firstFieldErrors) && firstFieldErrors.length > 0) {
        return firstFieldErrors[0]
      }
    }
  }

  return errorData.detail || errorData.message || errorData.status?.[0] || errorData.priority?.[0] || t('complaints', 'failedToUpdateComplaint')
}

function syncForm() {
  if (!complaint.value) return

  const normalized = normalizeComplaintPayload(complaint.value)
  editForm.value = {
    status: normalized.status || 'placed',
    priority: normalized.priority || 'low',
    admin_comment: normalized.admin_comment || '',
  }
}

async function fetchComplaint() {
  loading.value = true
  fetchError.value = ''
  mapLoaded.value = false

  try {
    const response = await complaintsApi.getById(route.params.id)
    const payload = response.data?.data || response.data || {}
    complaint.value = normalizeComplaintPayload(payload)
    syncForm()
    
    if (hasCoordinates.value) {
      await nextTick()
      setTimeout(() => {
        initMap()
      }, 100)
    }
  } catch (error) {
    fetchError.value = t('complaints', 'unableToLoadComplaint')
  } finally {
    loading.value = false
  }
}

function resetForm() {
  editError.value = ''
  editSuccess.value = ''
  syncForm()
}

// Watch for ID changes to re-initialize the component state
watch(() => route.params.id, (newId) => {
  if (newId) {
    if (mapInstance.value) {
      mapInstance.value.remove()
      mapInstance.value = null
    }
    fetchComplaint()
  }
})

async function initMap() {
  if (!complaint.value || mapLoaded.value) return
  
  const lat = parseFloat(complaint.value.latitude)
  const lng = parseFloat(complaint.value.longitude)

  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return

  await loadLeafletAssets()

  const mapContainer = document.getElementById('single-report-map')
  if (!mapContainer) return

  if (mapInstance.value) {
    mapInstance.value.remove()
  }

  mapInstance.value = window.L.map('single-report-map', {
    center: [lat, lng],
    zoom: 16,
    scrollWheelZoom: false,
  })

  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors',
    maxZoom: 18,
  }).addTo(mapInstance.value)

  const marker = window.L.marker([lat, lng]).addTo(mapInstance.value)
  marker.bindTooltip(t('common', 'openInGoogleMaps'), {
    direction: 'top',
    opacity: 0.9,
  })

  const googleMapsUrl = `https://www.google.com/maps?q=${lat},${lng}`
  mapInstance.value.on('click', () => {
    window.open(googleMapsUrl, '_blank')
  })
  marker.on('click', () => {
    window.open(googleMapsUrl, '_blank')
  })
  
  mapLoaded.value = true
  
  setTimeout(() => {
    if (mapInstance.value) {
      mapInstance.value.invalidateSize()
    }
  }, 200)
}

async function updateComplaint() {
  if (!complaint.value) return

  savingComplaint.value = true
  editError.value = ''
  editSuccess.value = ''

  try {
    const body = {
      status: editForm.value.status,
      priority: editForm.value.priority,
      admin_comment: editForm.value.admin_comment,
    }

    const response = await complaintsApi.update(complaint.value.id, body)
    const updatedPayload = response.data?.data || response.data || {}

    if (updatedPayload && typeof updatedPayload === 'object') {
      complaint.value = normalizeComplaintPayload(updatedPayload)
      syncForm()
    } else {
      await fetchComplaint()
    }

    editSuccess.value = t('complaints', 'complaintUpdated')
  } catch (error) {
    editError.value = parseError(error)
  } finally {
    savingComplaint.value = false
  }
}

onMounted(() => {
  window.addEventListener('keydown', handleKeydown)
  fetchComplaint()
})
</script>

<style scoped>
/* ── Thumbnail grid ─────────────────────────────────── */
.media-detail-row {
  align-items: flex-start;
}

.complaint-media-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  width: 100%;
}

.media-thumb-btn {
  position: relative;
  width: 148px;
  height: 110px;
  border: none;
  padding: 0;
  border-radius: var(--radius-lg);
  overflow: hidden;
  cursor: zoom-in;
  background: var(--surface-muted);
  box-shadow: 0 2px 8px rgba(29, 41, 57, 0.10);
  transition:
    transform 200ms var(--ease-spring),
    box-shadow 200ms var(--ease-out);
}

.media-thumb-btn:hover {
  transform: translateY(-3px) scale(1.03);
  box-shadow: 0 10px 28px rgba(47, 111, 237, 0.18);
}

.media-thumb {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
  transition: filter 200ms var(--ease-out);
}

.media-thumb-btn:hover .media-thumb {
  filter: brightness(0.72);
}

.media-thumb-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 1.5rem;
  opacity: 0;
  transition: opacity 200ms var(--ease-out);
}

.media-thumb-btn:hover .media-thumb-overlay {
  opacity: 1;
}

/* ── Viewer backdrop ────────────────────────────────── */
.img-viewer-backdrop {
  position: fixed;
  inset: 0;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(10, 12, 18, 0.88);
  backdrop-filter: blur(10px);
  padding: 20px;
  outline: none;
}

/* ── Viewer shell ───────────────────────────────────── */
.img-viewer-shell {
  display: flex;
  flex-direction: column;
  gap: 14px;
  width: min(92vw, 900px);
  max-height: 92vh;
}

/* ── Top bar ────────────────────────────────────────── */
.img-viewer-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 14px;
  border-radius: var(--radius-lg);
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.12);
  backdrop-filter: blur(8px);
}

.img-viewer-counter {
  display: flex;
  align-items: center;
  gap: 8px;
  color: rgba(255, 255, 255, 0.82);
  font-size: 0.88rem;
  font-weight: 600;
}

.img-viewer-close-btn {
  width: 36px;
  height: 36px;
  border: none;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.12);
  color: #fff;
  font-size: 1rem;
  display: grid;
  place-items: center;
  cursor: pointer;
  transition: background 160ms, transform 160ms var(--ease-spring);
}

.img-viewer-close-btn:hover {
  background: rgba(240, 68, 56, 0.75);
  transform: scale(1.1);
}

/* ── Stage (image + nav arrows) ─────────────────────── */
.img-viewer-stage {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--radius-xl);
  overflow: hidden;
  background: #090c14;
  max-height: calc(92vh - 110px);
}

.img-viewer-img {
  display: block;
  max-width: 100%;
  max-height: calc(92vh - 110px);
  width: auto;
  height: auto;
  object-fit: contain;
  border-radius: var(--radius-xl);
  user-select: none;
}

/* ── Nav arrows ─────────────────────────────────────── */
.img-viewer-nav {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 44px;
  height: 44px;
  border: none;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.14);
  color: #fff;
  font-size: 1rem;
  display: grid;
  place-items: center;
  cursor: pointer;
  z-index: 2;
  transition: background 160ms, transform 200ms var(--ease-spring);
}

.img-viewer-nav:hover {
  background: rgba(47, 111, 237, 0.72);
  transform: translateY(-50%) scale(1.1);
}

.img-viewer-nav--prev { left: 14px; }
.img-viewer-nav--next { right: 14px; }

/* ── Dot strip ──────────────────────────────────────── */
.img-viewer-dots {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
}

.img-viewer-dot {
  width: 8px;
  height: 8px;
  border: none;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.3);
  cursor: pointer;
  padding: 0;
  transition: background 200ms, transform 200ms var(--ease-spring);
}

.img-viewer-dot.active {
  background: var(--primary);
  transform: scale(1.4);
}

/* ── Backdrop enter/leave transition ────────────────── */
.viewer-enter-active,
.viewer-leave-active {
  transition: opacity 220ms var(--ease-out);
}
.viewer-enter-active .img-viewer-shell,
.viewer-leave-active .img-viewer-shell {
  transition: transform 260ms var(--ease-spring), opacity 220ms var(--ease-out);
}
.viewer-enter-from,
.viewer-leave-to {
  opacity: 0;
}
.viewer-enter-from .img-viewer-shell,
.viewer-leave-to .img-viewer-shell {
  transform: scale(0.93) translateY(14px);
  opacity: 0;
}

/* ── Image swap transition ──────────────────────────── */
.img-swap-enter-active,
.img-swap-leave-active {
  transition: opacity 160ms var(--ease-out), transform 160ms var(--ease-out);
}
.img-swap-enter-from {
  opacity: 0;
  transform: scale(0.97);
}
.img-swap-leave-to {
  opacity: 0;
  transform: scale(1.02);
}
</style>
