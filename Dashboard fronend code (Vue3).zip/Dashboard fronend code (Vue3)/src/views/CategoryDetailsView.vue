<template>
  <div class="category-details-view">
    <div class="topbar">
      <div class="page-intro">
      <span class="eyebrow"><i class="fas fa-folder-open"></i> {{ t('categories', 'categoryPage') }}</span>
      <h2 class="page-title">{{ category ? category.name : `${t('common', 'category')} #${route.params.id}` }}</h2>
      <p class="page-subtitle">{{ t('categories', 'reviewEditPage') }}</p>
    </div>

    <div class="topbar-actions">
      <RouterLink class="btn-secondary" :to="{ name: 'Categories' }">
        <i class="fas fa-arrow-left"></i>
        {{ t('common', 'back') }}
      </RouterLink>
    </div>
  </div>

  <div v-if="loading" class="empty-state">
    <h3>{{ t('categories', 'loadingCategory') }}</h3>
  </div>

  <div v-else-if="fetchError" class="error-message">
    <i class="fas fa-circle-exclamation"></i>
    <span>{{ fetchError }}</span>
  </div>

  <template v-else-if="category">
    <div class="hero-banner">
      <div>
        <span class="status-pill" :class="categoryForm.is_active ? 'success' : 'warning'">
          {{ categoryForm.is_active ? t('common', 'active') : t('common', 'inactive') }}
        </span>
        <h3 style="margin: 14px 0 8px;">{{ t('common', 'category') }} #{{ category.id }}</h3>
        <p class="muted-text" style="margin: 0;">{{ t('categories', 'useThisPage') }}</p>
      </div>
    </div>

    <div class="details-page-grid">
      <section class="detail-card">
        <div class="card-head">
          <div>
            <span class="eyebrow">{{ t('common', 'details') }}</span>
            <h3>{{ t('categories', 'currentCategory') }}</h3>
          </div>
        </div>

        <div class="detail-list">
          <div class="detail-row">
            <label>{{ t('common', 'id') }}</label>
            <span>#{{ category.id }}</span>
          </div>
          <div class="detail-row">
            <label>{{ t('common', 'name') }}</label>
            <span>{{ category.name }}</span>
          </div>
          <div class="detail-row">
            <label>{{ t('common', 'status') }}</label>
            <span>{{ category.is_active ? t('common', 'active') : t('common', 'inactive') }}</span>
          </div>
        </div>
      </section>

      <section class="detail-card">
        <div class="card-head">
          <div>
            <span class="eyebrow">{{ t('common', 'editSection') }}</span>
            <h3>{{ t('categories', 'updateCategory') }}</h3>
          </div>
        </div>

        <div v-if="formError" class="error-message">
          <i class="fas fa-circle-exclamation"></i>
          <span>{{ formError }}</span>
        </div>
        <div v-if="formSuccess" class="success-message">
          <i class="fas fa-circle-check"></i>
          <span>{{ formSuccess }}</span>
        </div>

        <form class="edit-form" @submit.prevent="updateCategory">
          <div class="form-group">
            <label>{{ t('common', 'name') }}</label>
            <input v-model="categoryForm.name" type="text" class="input" required />
          </div>

          <div class="form-group toggle-row">
            <label>{{ t('common', 'active') }}</label>
            <input v-model="categoryForm.is_active" type="checkbox" />
          </div>

          <div class="form-actions">
            <button type="submit" class="button-submit" :disabled="saving">
              {{ saving ? t('settings', 'saving') : t('common', 'save') }}
            </button>
            <button type="button" class="btn-cancel" @click="resetForm">{{ t('common', 'reset') }}</button>
          </div>
        </form>
      </section>
    </div>
  </template>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import { categoriesApi } from '../api/categories'
import { t } from '../utils/i18n'

const route = useRoute()
const loading = ref(false)
const saving = ref(false)
const category = ref(null)
const fetchError = ref('')
const formError = ref('')
const formSuccess = ref('')

const categoryForm = ref({
  name: '',
  is_active: true,
})

function parseError(error, fallback) {
  const errorData = error.response?.data
  if (typeof errorData === 'string') return errorData
  return errorData?.detail || errorData?.name?.[0] || fallback
}

function syncForm() {
  if (!category.value) return
  categoryForm.value = {
    name: category.value.name || '',
    is_active: category.value.is_active ?? true,
  }
}

async function fetchCategory() {
  loading.value = true
  fetchError.value = ''

  try {
    const response = await categoriesApi.getById(route.params.id)
    category.value = response.data.data || response.data
    syncForm()
  } catch (error) {
    fetchError.value = t('categories', 'unableLoadCategory')
  } finally {
    loading.value = false
  }
}

function resetForm() {
  formError.value = ''
  formSuccess.value = ''
  syncForm()
}

async function updateCategory() {
  if (!category.value) return

  saving.value = true
  formError.value = ''
  formSuccess.value = ''

  try {
    const body = {
      name: categoryForm.value.name,
      is_active: categoryForm.value.is_active,
    }

    await categoriesApi.update(category.value.id, body)
    formSuccess.value = t('categories', 'categoryUpdated')
    await fetchCategory()
  } catch (error) {
    formError.value = parseError(error, t('categories', 'failedUpdateCategory'))
  } finally {
    saving.value = false
  }
}

onMounted(fetchCategory)
</script>
