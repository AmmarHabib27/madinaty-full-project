<template>
  <div class="settings-view">
    <div class="topbar">
      <div class="page-intro">
      <span class="eyebrow"><i class="fas fa-sliders"></i> {{ t('settings', 'accountSettings') }}</span>
      <h2 class="page-title">{{ t('settings', 'updateProfileWithoutLeaving') }}</h2>
      <p class="page-subtitle">{{ t('settings', 'validationInline') }}</p>
    </div>
  </div>

  <div class="settings-wrapper">
    <div class="settings-tabs">
      <button :class="['tab-button', { active: activeTab === 'profile' }]" @click="activeTab = 'profile'">
        <i class="fas fa-user-circle"></i>
        {{ t('common', 'profile') }}
      </button>
      <button :class="['tab-button', { active: activeTab === 'password' }]" @click="activeTab = 'password'">
        <i class="fas fa-key"></i>
        {{ t('settings', 'changePassword') }}
      </button>
    </div>

    <div v-if="activeTab === 'profile'" class="page-panel">
      <div class="card-head">
        <div>
          <span class="eyebrow">{{ t('common', 'profile') }}</span>
          <h3>{{ t('settings', 'adminInformation') }}</h3>
        </div>
        <span class="pill">{{ t('settings', 'accountDetails') }}</span>
      </div>

      <div v-if="loading" class="empty-state">
        <h3>{{ t('settings', 'loadingProfile') }}</h3>
      </div>

      <div v-else-if="profileData" class="profile-card">
        <div class="profile-header">
          <img :src="profileImage" alt="Profile" class="profile-avatar" @error="usePlaceholderImage" />
          <div class="profile-header-info">
            <h4 style="margin: 0 0 6px;">{{ profileData.name || t('common', 'unknown') }}</h4>
            <p class="muted-text" style="margin: 0;">{{ profileData.phone || t('settings', 'noPhoneNumber') }}</p>
          </div>
        </div>

        <div class="detail-list">
          <div class="detail-row">
            <label>{{ t('settings', 'fullName') }}</label>
            <span>{{ profileData.name || t('common', 'na') }}</span>
          </div>
          <div class="detail-row">
            <label>{{ t('common', 'phone') }}</label>
            <span>{{ profileData.phone || t('common', 'na') }}</span>
          </div>
          <div class="detail-row">
            <label>{{ t('settings', 'joined') }}</label>
            <span>{{ formatDate(profileData.created_at) }}</span>
          </div>
        </div>

        <div class="form-actions">
          <button class="btn-edit" type="button" @click="editProfile = !editProfile">
            <i class="fas fa-edit"></i>
            {{ editProfile ? t('common', 'close') : t('settings', 'editProfile') }}
          </button>
        </div>

        <div v-if="profileError" class="error-message">
          <i class="fas fa-circle-exclamation"></i>
          <span>{{ profileError }}</span>
        </div>

        <div v-if="profileSuccess" class="success-message">
          <i class="fas fa-circle-check"></i>
          <span>{{ profileSuccess }}</span>
        </div>

        <form v-if="editProfile" class="edit-form" @submit.prevent="updateProfile">
          <div class="form-group">
            <label>{{ t('settings', 'fullName') }}</label>
            <input v-model="editFormData.name" type="text" class="input" />
          </div>

          <div class="form-group">
            <label>{{ t('common', 'phone') }}</label>
            <input v-model="editFormData.phone" type="tel" class="input" />
          </div>

          <div class="form-group">
            <label>{{ t('settings', 'profilePicture') }}</label>
            <div class="file-upload-wrapper">
              <input
                id="profile-picture"
                ref="fileInput"
                type="file"
                accept="image/*"
                class="file-input"
                @change="handleFileSelect"
              />
              <label for="profile-picture" class="file-upload-btn">
                <i class="fas fa-camera"></i>
                {{ t('settings', 'chooseImage') }}
              </label>
              <span v-if="editFormData.profile_picture" class="file-selected">
                {{ editFormData.profile_picture.name }}
              </span>
              <span v-else class="file-placeholder">{{ t('settings', 'noFileSelected') }}</span>
            </div>
          </div>

          <div class="form-actions">
            <button type="submit" class="btn-save" :disabled="savingProfile">
              <i class="fas fa-save"></i>
              {{ savingProfile ? t('settings', 'saving') : t('common', 'save') }}
            </button>
            <button type="button" class="btn-cancel" @click="cancelEdit">{{ t('common', 'cancel') }}</button>
          </div>
        </form>
      </div>

      <div v-else class="empty-state">
        <h3>{{ t('settings', 'profileNotAvailable') }}</h3>
        <p class="muted-text">{{ t('settings', 'profileRequestFailed') }}</p>
      </div>
    </div>

    <div v-if="activeTab === 'password'" class="page-panel">
      <div class="card-head">
        <div>
          <span class="eyebrow">{{ t('settings', 'security') }}</span>
          <h3>{{ t('settings', 'changePassword') }}</h3>
        </div>
        <span class="pill">{{ t('settings', 'secureUpdate') }}</span>
      </div>

      <form class="password-form" @submit.prevent="submitChangePassword">
        <div class="form-group">
          <label>{{ t('settings', 'currentPassword') }}</label>
          <div class="password-input-wrapper">
            <input
              v-model="passwordForm.old_password"
              :type="showOldPass ? 'text' : 'password'"
              class="input"
              :placeholder="t('settings', 'currentPasswordPlaceholder')"
              required
            />
            <button type="button" class="toggle-pass" tabindex="-1" @click="showOldPass = !showOldPass">
              <i :class="['fas', showOldPass ? 'fa-eye' : 'fa-eye-slash']"></i>
            </button>
          </div>
        </div>

        <div class="form-group">
          <label>{{ t('settings', 'newPassword') }}</label>
          <div class="password-input-wrapper">
            <input
              v-model="passwordForm.new_password"
              :type="showNewPass ? 'text' : 'password'"
              class="input"
              :placeholder="t('settings', 'newPasswordPlaceholder')"
              required
            />
            <button type="button" class="toggle-pass" tabindex="-1" @click="showNewPass = !showNewPass">
              <i :class="['fas', showNewPass ? 'fa-eye' : 'fa-eye-slash']"></i>
            </button>
          </div>
        </div>

        <div class="form-group">
          <label>{{ t('settings', 'confirmNewPassword') }}</label>
          <div class="password-input-wrapper">
            <input
              v-model="passwordForm.confirm_password"
              :type="showConfirmPass ? 'text' : 'password'"
              class="input"
              :placeholder="t('settings', 'confirmNewPasswordPlaceholder')"
              required
            />
            <button type="button" class="toggle-pass" tabindex="-1" @click="showConfirmPass = !showConfirmPass">
              <i :class="['fas', showConfirmPass ? 'fa-eye' : 'fa-eye-slash']"></i>
            </button>
          </div>
        </div>

        <div v-if="passwordError" class="error-message">
          <i class="fas fa-circle-exclamation"></i>
          <span>{{ passwordError }}</span>
        </div>

        <div v-if="passwordSuccess" class="success-message">
          <i class="fas fa-circle-check"></i>
          <span>{{ passwordSuccess }}</span>
        </div>

        <button type="submit" class="button-submit" :disabled="loadingPassword">
          <i class="fas fa-save"></i>
          {{ loadingPassword ? t('settings', 'updatingPassword') : t('settings', 'updatePassword') }}
        </button>
      </form>
    </div>
  </div>
</div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useAuthStore } from '../stores/auth'
import { useProfileStore } from '../stores/profile'
import { t } from '../utils/i18n'

const route = useRoute()
const authStore = useAuthStore()
const profileStore = useProfileStore()

const activeTab = ref(route.query.tab || 'profile')
const loading = ref(false)
const savingProfile = ref(false)
const loadingPassword = ref(false)
const editProfile = ref(false)
const profileData = computed(() => profileStore.profile)
const fileInput = ref(null)

const showOldPass = ref(false)
const showNewPass = ref(false)
const showConfirmPass = ref(false)

const editFormData = ref({
  name: '',
  phone: '',
  profile_picture: null,
})

const passwordForm = ref({
  old_password: '',
  new_password: '',
  confirm_password: '',
})

const profileError = ref('')
const profileSuccess = ref('')
const passwordError = ref('')
const passwordSuccess = ref('')
const previewUrl = ref('')

import { DEFAULT_PROFILE_IMAGE, normalizeMediaUrl } from '../utils/mediaHelper'

const profileImage = computed(() => {
  if (previewUrl.value) return previewUrl.value
  return normalizeMediaUrl(profileData.value?.profile_picture) || DEFAULT_PROFILE_IMAGE
})

function usePlaceholderImage(event) {
  if (event.target.src.endsWith(DEFAULT_PROFILE_IMAGE)) return
  event.target.src = DEFAULT_PROFILE_IMAGE
}

watch(
  () => editFormData.value.profile_picture,
  (file) => {
    if (previewUrl.value) {
      URL.revokeObjectURL(previewUrl.value)
      previewUrl.value = ''
    }

    if (file instanceof File) {
      previewUrl.value = URL.createObjectURL(file)
    }
  },
)

onBeforeUnmount(() => {
  if (previewUrl.value) {
    URL.revokeObjectURL(previewUrl.value)
  }
})

function parseError(error, fallback) {
  const errorData = error.response?.data
  if (typeof errorData === 'string') return errorData
  return (
    errorData?.detail ||
    errorData?.name?.[0] ||
    errorData?.phone?.[0] ||
    errorData?.profile_picture?.[0] ||
    errorData?.non_field_errors?.[0] ||
    fallback
  )
}

async function fetchProfile() {
  loading.value = true
  profileError.value = ''

  try {
    await profileStore.fetchProfile()
    editFormData.value = {
      name: profileStore.profile?.name || '',
      phone: profileStore.profile?.phone || '',
      profile_picture: null,
    }
  } catch (error) {
    profileError.value = t('settings', 'failedLoadProfile')
  } finally {
    loading.value = false
  }
}

function handleFileSelect(event) {
  const file = event.target.files[0]
  if (!file) return

  if (!file.type.startsWith('image/')) {
    profileError.value = t('settings', 'imageFileRequired')
    event.target.value = ''
    return
  }

  if (file.size > 5 * 1024 * 1024) {
    profileError.value = t('settings', 'imageSizeError')
    event.target.value = ''
    return
  }

  profileError.value = ''
  profileSuccess.value = ''
  editFormData.value.profile_picture = file
}

function cancelEdit() {
  editProfile.value = false
  profileError.value = ''
  profileSuccess.value = ''
  editFormData.value = {
    name: profileData.value?.name || '',
    phone: profileData.value?.phone || '',
    profile_picture: null,
  }

  if (fileInput.value) {
    fileInput.value.value = ''
  }
}

async function updateProfile() {
  savingProfile.value = true
  profileError.value = ''
  profileSuccess.value = ''

  try {
    const response = await profileStore.updateProfile(editFormData.value)
    profileSuccess.value = t('settings', 'profileUpdated')
    editProfile.value = false
    editFormData.value.profile_picture = null

    if (fileInput.value) {
      fileInput.value.value = ''
    }
  } catch (error) {
    profileError.value = parseError(error, t('settings', 'failedUpdateProfile'))
  } finally {
    savingProfile.value = false
  }
}

async function submitChangePassword() {
  passwordError.value = ''
  passwordSuccess.value = ''

  if (passwordForm.value.new_password !== passwordForm.value.confirm_password) {
    passwordError.value = t('settings', 'passwordsDoNotMatch')
    return
  }

  loadingPassword.value = true

  try {
    await authStore.changePassword(
      passwordForm.value.old_password,
      passwordForm.value.new_password,
      passwordForm.value.confirm_password,
    )

    passwordSuccess.value = t('settings', 'passwordUpdated')
    passwordForm.value = {
      old_password: '',
      new_password: '',
      confirm_password: '',
    }
    showOldPass.value = false
    showNewPass.value = false
    showConfirmPass.value = false
  } catch (error) {
    const errorData = error.response?.data
    if (typeof errorData === 'string') {
      passwordError.value = errorData
    } else if (errorData?.detail) {
      passwordError.value = errorData.detail
    } else if (errorData?.old_password?.[0]) {
      passwordError.value = `Current password is incorrect: ${errorData.old_password[0]}`
    } else if (errorData?.new_password?.[0]) {
      passwordError.value = `New password error: ${errorData.new_password[0]}`
    } else if (errorData?.non_field_errors?.[0]) {
      passwordError.value = errorData.non_field_errors[0]
    } else {
      passwordError.value = t('settings', 'failedChangePassword')
    }
  } finally {
    loadingPassword.value = false
  }
}

function formatDate(dateString) {
  if (!dateString) return t('common', 'na')
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })
}

onMounted(fetchProfile)
</script>
