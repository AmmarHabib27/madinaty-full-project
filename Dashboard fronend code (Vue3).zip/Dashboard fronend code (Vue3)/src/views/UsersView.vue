<template>
  <div class="users-view">
    <div class="topbar">
      <div class="page-intro">
        <span class="eyebrow"><i class="fas fa-users-gear"></i> {{ t('users', 'teamAccess') }}</span>
      <h2 class="page-title">{{ t('users', 'cleanerRoleOverview') }}</h2>
      <p class="page-subtitle">{{ t('users', 'usersApiHint') }}</p>
    </div>

    <div class="topbar-actions">
      <button class="btn-secondary" type="button" @click="fetchUsers(currentPage)" :disabled="loading">
        <i class="fas fa-rotate-right"></i>
        {{ t('common', 'refresh') }}
      </button>
    </div>
  </div>

  <div v-if="loading" class="empty-state">
    <h3>{{ t('users', 'loadingUsers') }}</h3>
  </div>

  <div v-else-if="fetchError" class="error-message">
    <i class="fas fa-circle-exclamation"></i>
    <span>{{ fetchError }}</span>
  </div>

  <div v-else class="users-list">
    <div v-if="users.length === 0" class="empty-state">
      <h3>{{ t('users', 'noUsersFound') }}</h3>
      <p class="muted-text">{{ t('users', 'tryRefreshing') }}</p>
    </div>

    <div v-for="user in users" :key="user.id" class="user-card">
      <img :src="avatarUrl(user)" :alt="`${user.name || t('common', 'user')} avatar`" @error="usePlaceholderImage" />

      <div class="user-info">
        <h4>{{ user.name || t('common', 'unknown') }}</h4>
        <p><strong>{{ t('common', 'phone') }}:</strong> {{ user.phone || t('common', 'na') }}</p>
        <p>
          <strong>{{ t('common', 'status') }}:</strong>
          <span :class="['status-pill', user.is_active ? 'success' : 'warning']">
            {{ user.is_active ? t('common', 'active') : t('common', 'inactive') }}
          </span>
        </p>
        <p><strong>{{ t('common', 'created') }}:</strong> {{ formatDate(user.created_at) }}</p>
      </div>

      <div class="stack-actions">
        <button class="btn-secondary" type="button">{{ t('users', 'permissions') }}</button>
      </div>
    </div>

    <div class="pagination-controls" v-if="pagination.previous || pagination.next">
      <button class="btn-secondary" type="button" :disabled="!pagination.previous || loading" @click="changeUserPage(currentPage - 1)">
        {{ t('users', 'previous') }}
      </button>
      <span class="page-summary">Page {{ currentPage }}</span>
      <button class="btn-secondary" type="button" :disabled="!pagination.next || loading" @click="changeUserPage(currentPage + 1)">
        {{ t('users', 'next') }}
      </button>
    </div>
  </div>
</div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { t } from '../utils/i18n'
import { usersApi } from '../api/users'
import { DEFAULT_PROFILE_IMAGE, normalizeMediaUrl } from '../utils/mediaHelper'

const users = ref([])
const loading = ref(false)
const fetchError = ref('')
const currentPage = ref(1)
const pagination = ref({})

const avatarUrl = (user) => {
  return normalizeMediaUrl(user?.profile_picture || user?.image || user?.avatar) || DEFAULT_PROFILE_IMAGE
}

function usePlaceholderImage(event) {
  if (event.target.src.endsWith(DEFAULT_PROFILE_IMAGE)) return
  event.target.src = DEFAULT_PROFILE_IMAGE
}

function formatDate(value) {
  if (!value) return 'N/A'
  return new Date(value).toLocaleString()
}

async function fetchUsers(page = 1) {
  loading.value = true
  fetchError.value = ''

  try {
    currentPage.value = page
    const response = await usersApi.getAll({ page })
    users.value = response.data.data || []
    pagination.value = response.data.pagination || {}
  } catch (error) {
    fetchError.value = t('users', 'unableLoadUsers')
  } finally {
    loading.value = false
  }
}

function changeUserPage(page) {
  if (page < 1) return
  fetchUsers(page)
}

onMounted(() => fetchUsers())
</script>
