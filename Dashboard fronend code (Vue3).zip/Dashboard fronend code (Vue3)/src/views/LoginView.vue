<template>
  <div class="login-page">
    <div class="login-shell">
      <section class="login-hero">
        <span class="login-badge">{{ t('auth', 'adminAccess') }}</span>
        <h1 class="page-title">{{ t('auth', 'adminAccess') }}</h1>
        <p class="page-subtitle">
          {{ t('auth', 'signInHint') }}
        </p>

        <div class="login-points">
          <div class="login-point">
            <span class="status-pill success"><i class="fas fa-circle-check"></i> {{ t('auth', 'liveReports') }}</span>
            <span class="muted-text">{{ t('auth', 'followIssueFlow') }}</span>
          </div>
          <div class="login-point">
            <span class="status-pill"><i class="fas fa-bullhorn"></i> {{ t('auth', 'newsUpdates') }}</span>
            <span class="muted-text">{{ t('auth', 'publishAnnouncements') }}</span>
          </div>
          <div class="login-point">
            <span class="status-pill warning"><i class="fas fa-shield-halved"></i> {{ t('auth', 'secureAccess') }}</span>
            <span class="muted-text">{{ t('auth', 'passwordControlsReady') }}</span>
          </div>
        </div>
      </section>

      <form class="form" @submit.prevent="handleLogin">
        <div style="text-align: center;">
          <img :src="props.isDarkMode ? '/logo%20dark.png' : '/logo.png'" alt="Logo" style="max-height: 56px;" />
        </div>

        <div style="text-align: center;">
          <h2 style="margin: 0; font-size: 1.8rem;">{{ t('auth', 'welcomeBack') }}</h2>
          <p class="muted-text" style="margin-top: 8px;">{{ t('auth', 'signInHint') }}</p>
        </div>

        <div class="flex-column">
          <label>{{ t('auth', 'phone') }}</label>
        </div>
        <div class="inputForm">
          <svg class="login-input-icon" height="18" viewBox="0 0 24 24" width="18" fill="none" stroke="currentColor" stroke-width="2" xmlns="http://www.w3.org/2000/svg">
            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.4A2 2 0 0 1 3.6 1.22h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.82a16 16 0 0 0 6.29 6.29l.96-.96a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" />
          </svg>
          <input v-model="phone" type="text" class="input" :placeholder="t('auth', 'enterPhone')" required />
        </div>

        <div class="flex-column" style="margin-top: 4px;">
          <label>{{ t('auth', 'password') }}</label>
        </div>
        <div class="inputForm">
          <svg class="login-input-icon" height="18" viewBox="-64 0 512 512" width="18" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path d="m336 512h-288c-26.453125 0-48-21.523438-48-48v-224c0-26.476562 21.546875-48 48-48h288c26.453125 0 48 21.523438 48 48v224c0 26.476562-21.546875 48-48 48zm-288-288c-8.8125 0-16 7.167969-16 16v224c0 8.832031 7.1875 16 16 16h288c8.8125 0 16-7.167969 16-16v-224c0-8.832031-7.1875-16-16-16zm0 0" />
            <path d="m304 224c-8.832031 0-16-7.167969-16-16v-80c0-52.929688-43.070312-96-96-96s-96 43.070312-96 96v80c0 8.832031-7.167969 16-16 16s-16-7.167969-16-16v-80c0-70.59375 57.40625-128 128-128s128 57.40625 128 128v80c0 8.832031-7.167969 16-16 16zm0 0" />
          </svg>
          <input v-model="password" :type="showPass ? 'text' : 'password'" class="input" :placeholder="t('auth', 'enterPassword')" required />
          <i
            :class="['fas', showPass ? 'fa-eye' : 'fa-eye-slash']"
            class="login-password-toggle"
            @click="showPass = !showPass"
          ></i>
        </div>

        <div v-if="errorMsg" class="error-message">
          <i class="fas fa-circle-exclamation"></i>
          <span>{{ errorMsg }}</span>
        </div>

        <button type="submit" class="button-submit" :disabled="loading">
          {{ loading ? t('auth', 'signingIn') : t('auth', 'signIn') }}
        </button>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'
import { t } from '../utils/i18n'

const props = defineProps({
  isDarkMode: {
    type: Boolean,
    default: false,
  },
})

const router = useRouter()
const auth = useAuthStore()

const phone = ref('')
const password = ref('')
const showPass = ref(false)
const loading = ref(false)
const errorMsg = ref('')

async function handleLogin() {
  loading.value = true
  errorMsg.value = ''

  try {
    await auth.login(phone.value, password.value)
    router.push({ name: 'Dashboard' })
  } catch (error) {
    errorMsg.value = error.response?.data?.message || t('auth', 'loginFailed')
  } finally {
    loading.value = false
  }
}
</script>
