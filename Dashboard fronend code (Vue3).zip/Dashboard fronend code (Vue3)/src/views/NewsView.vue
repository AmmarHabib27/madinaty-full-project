<template>
  <div class="news-view">
    <div class="topbar">
      <div class="page-intro">
        <span class="eyebrow"><i class="fas fa-bullhorn"></i> {{ t('news', 'newsCenter') }}</span>
      <h2 class="page-title">{{ t('news', 'createNewsHere') }}</h2>
      <p class="page-subtitle">{{ t('news', 'listStaysSimple') }}</p>
    </div>

    <div class="topbar-actions">
      <button class="btn-reports" type="button" @click="toggleForm">
        <i class="fas" :class="showCreate ? 'fa-chevron-up' : 'fa-plus'"></i>
        {{ showCreate ? t('news', 'hideForm') : t('news', 'addNews') }}
      </button>
      <button class="btn-secondary" type="button" @click="fetchNews(currentPage)" :disabled="loading">
        <i class="fas fa-rotate-right"></i>
        {{ t('common', 'refresh') }}
      </button>
    </div>
  </div>

  <div v-if="showCreate" class="page-panel" style="margin-bottom: 18px;">
    <div class="card-head">
      <div>
        <span class="eyebrow">{{ t('news', 'createMode') }}</span>
        <h3>{{ t('news', 'publishNewAnnouncement') }}</h3>
      </div>
      <span class="pill">{{ t('news', 'inlineCreate') }}</span>
    </div>

    <form class="news-form" @submit.prevent="createNews">
      <div class="form-group">
        <label>{{ t('common', 'title') }}</label>
        <input v-model="newsForm.title" type="text" class="input" :placeholder="t('news', 'newsTitlePlaceholder')" required />
      </div>

      <div class="form-group">
        <label>{{ t('common', 'body') }}</label>
        <textarea v-model="newsForm.body" class="input" rows="5" :placeholder="t('news', 'writeAnnouncement')" required></textarea>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>{{ t('news', 'startDate') }}</label>
          <input v-model="newsForm.start_date" type="datetime-local" class="input" required />
        </div>
        <div class="form-group">
          <label>{{ t('news', 'expiryDate') }}</label>
          <input v-model="newsForm.expiry_date" type="datetime-local" class="input" required />
        </div>
      </div>

      <div class="form-group">
        <label>{{ t('common', 'image') }}</label>
        <input type="file" accept="image/*" @change="handleImageSelect" class="input" />
        <small v-if="newsForm.image">{{ t('news', 'selectedFile', { file: newsForm.image.name }) }}</small>
      </div>

      <div class="form-group toggle-row">
        <label>{{ t('common', 'active') }}</label>
        <input v-model="newsForm.is_active" type="checkbox" />
      </div>

      <div v-if="createError" class="error-message">
        <i class="fas fa-circle-exclamation"></i>
        <span>{{ createError }}</span>
      </div>
      <div v-if="createSuccess" class="success-message">
        <i class="fas fa-circle-check"></i>
        <span>{{ createSuccess }}</span>
      </div>

      <div class="form-actions">
        <button type="submit" class="button-submit" :disabled="savingNews">
          {{ savingNews ? t('common', 'loading') : t('news', 'publishNewAnnouncement') }}
        </button>
        <button type="button" class="btn-cancel" @click="cancelCreate">{{ t('common', 'clear') }}</button>
      </div>
    </form>
  </div>

  <div v-if="fetchError" class="error-message">
    <i class="fas fa-circle-exclamation"></i>
    <span>{{ fetchError }}</span>
  </div>

  <div class="table-shell">
    <div class="table-toolbar">
      <div class="card-head">
        <div>
          <h3 class="table-title">{{ t('news', 'publishedAnnouncements') }}</h3>
          <p class="muted-text">{{ t('news', 'useOpenToManage') }}</p>
        </div>
        <span class="pill">{{ t('complaints', 'visibleCount', { count: newsItems.length }) }}</span>
      </div>
    </div>

    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            <th>{{ t('common', 'id') }}</th>
            <th>{{ t('common', 'title') }}</th>
            <th>{{ t('common', 'active') }}</th>
            <th>{{ t('news', 'startDate') }}</th>
            <th>{{ t('news', 'expiryDate') }}</th>
            <th>{{ t('common', 'created') }}</th>
            <th>{{ t('common', 'actions') }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="loading">
            <td colspan="7">{{ t('news', 'loadingNews') }}</td>
            </tr>
          <tr v-else-if="newsItems.length === 0">
            <td colspan="7">{{ t('news', 'noNewsItems') }}</td>
          </tr>
          <tr v-for="item in newsItems" :key="item.id">
            <td data-label="ID">#{{ item.id }}</td>
            <td data-label="Title">
              <div class="news-title-cell">
                <strong>{{ item.title }}</strong>
                <p class="news-body">{{ trimText(item.body) }}</p>
              </div>
            </td>
            <td data-label="Active">
              <span class="status-pill" :class="item.is_active ? 'success' : 'warning'">
                {{ item.is_active ? t('common', 'active') : t('common', 'inactive') }}
              </span>
            </td>
            <td data-label="Start">{{ formatDate(item.start_date) }}</td>
            <td data-label="Expiry">{{ formatDate(item.expiry_date) }}</td>
            <td data-label="Created">{{ formatDate(item.created_at) }}</td>
            <td data-label="Actions">
              <div class="action-buttons">
                <RouterLink class="btn-view" :to="{ name: 'NewsDetails', params: { id: item.id } }">{{ t('common', 'open') }}</RouterLink>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="pagination-controls" v-if="pagination.previous || pagination.next">
    <button class="btn-secondary" type="button" :disabled="!pagination.previous || loading" @click="changeNewsPage(currentPage - 1)">
      {{ t('users', 'previous') }}
    </button>
    <span class="page-summary">{{ t('common', 'page') }} {{ currentPage }}</span>
    <button class="btn-secondary" type="button" :disabled="!pagination.next || loading" @click="changeNewsPage(currentPage + 1)">
      {{ t('users', 'next') }}
    </button>
  </div>
</div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { newsApi } from '../api/news'
import { t } from '../utils/i18n'

const showCreate = ref(false)
const loading = ref(false)
const savingNews = ref(false)
const newsItems = ref([])
const createError = ref('')
const createSuccess = ref('')
const fetchError = ref('')
const currentPage = ref(1)
const pagination = ref({})

const newsForm = ref({
  title: '',
  body: '',
  image: null,
  start_date: '',
  expiry_date: '',
  is_active: true,
})

function formatDate(value) {
  if (!value) return t('common', 'na')
  return new Date(value).toLocaleString()
}

function trimText(text) {
  if (!text) return t('news', 'noBodyAvailable')
  return text.length > 90 ? `${text.slice(0, 90)}...` : text
}

function toggleForm() {
  showCreate.value = !showCreate.value
  if (!showCreate.value) {
    resetMessages()
  }
}

function resetMessages() {
  createError.value = ''
  createSuccess.value = ''
}

function resetForm() {
  newsForm.value = {
    title: '',
    body: '',
    image: null,
    start_date: '',
    expiry_date: '',
    is_active: true,
  }
}

function cancelCreate() {
  showCreate.value = false
  resetMessages()
  resetForm()
}

async function fetchNews(page = 1) {
  loading.value = true
  fetchError.value = ''

  try {
    currentPage.value = page
    const response = await newsApi.getAll({ page })
    newsItems.value = response.data.data || []
    pagination.value = response.data.pagination || {}
  } catch (error) {
    fetchError.value = t('news', 'unableLoadNews')
  } finally {
    loading.value = false
  }
}

function changeNewsPage(page) {
  if (page < 1) return
  fetchNews(page)
}

function handleImageSelect(event) {
  const file = event.target.files[0]
  if (!file) return

  if (!file.type.startsWith('image/')) {
    createError.value = t('news', 'validImage')
    event.target.value = ''
    return
  }

  createError.value = ''
  newsForm.value.image = file
}

function parseError(error, fallback) {
  const errorData = error.response?.data
  if (typeof errorData === 'string') return errorData
  return errorData?.detail || errorData?.title?.[0] || errorData?.body?.[0] || fallback
}

async function createNews() {
  resetMessages()
  savingNews.value = true

  try {
    const body = {
      title: newsForm.value.title,
      body: newsForm.value.body,
      start_date: newsForm.value.start_date,
      expiry_date: newsForm.value.expiry_date,
      is_active: newsForm.value.is_active,
      image: newsForm.value.image,
    }

    await newsApi.create(body)
    createSuccess.value = t('news', 'newsCreated')
    await fetchNews(1)
    resetForm()
  } catch (error) {
    createError.value = parseError(error, t('news', 'failedCreateNews'))
  } finally {
    savingNews.value = false
  }
}

onMounted(fetchNews)
</script>

<style scoped>
.news-title-cell {
  display: grid;
  gap: 6px;
}

.news-body {
  margin: 0;
  color: var(--text-soft);
}
</style>
