<template>
  <div class="my-view-view">

    <!-- Top bar -->
    <div class="topbar">
      <div class="page-intro">
        <span class="eyebrow"><i class="fas fa-map-location-dot"></i> {{ t('map', 'fieldSnapshot') }}</span>
        <h2 class="page-title">{{ t('map', 'allComplaintsAtGlance') }}</h2>
        <p class="page-subtitle">{{ t('map', 'filterByPriority') }}</p>
      </div>
    </div>

    <!-- Error -->
    <div v-if="fetchError" class="error-message">
      <i class="fas fa-circle-exclamation"></i>
      <span>{{ fetchError }}</span>
    </div>

    <!-- Stats row -->
    <div class="map-stats-row">
      <div class="map-stat-chip map-stat-chip--all" :class="{ active: activeFilter === 'all' }" @click="setFilter('all')">
        <i class="fas fa-layer-group"></i>
        <div>
          <span class="chip-count">{{ allComplaints.length }}</span>
          <span class="chip-label">{{ t('map', 'all') }}</span>
        </div>
      </div>
      <div class="map-stat-chip map-stat-chip--low" :class="{ active: activeFilter === 'low' }" @click="setFilter('low')">
        <i class="fas fa-circle-check"></i>
        <div>
          <span class="chip-count">{{ countByPriority('low') }}</span>
          <span class="chip-label">{{ formatPriorityLabel('low') }}</span>
        </div>
      </div>
      <div class="map-stat-chip map-stat-chip--intermediate" :class="{ active: activeFilter === 'intermediate' }" @click="setFilter('intermediate')">
        <i class="fas fa-circle-exclamation"></i>
        <div>
          <span class="chip-count">{{ countByPriority('intermediate') }}</span>
          <span class="chip-label">{{ formatPriorityLabel('intermediate') }}</span>
        </div>
      </div>
      <div class="map-stat-chip map-stat-chip--high" :class="{ active: activeFilter === 'high' }" @click="setFilter('high')">
        <i class="fas fa-triangle-exclamation"></i>
        <div>
          <span class="chip-count">{{ countByPriority('high') }}</span>
          <span class="chip-label">{{ formatPriorityLabel('high') }}</span>
        </div>
      </div>
    </div>

    <!-- Map + sidebar grid -->
    <div class="map-layout">

      <!-- Map -->
      <div class="map-card card-panel">
        <div class="card-head" style="margin-bottom: 12px;">
          <div>
            <span class="eyebrow">{{ t('map', 'map') }}</span>
            <h3>{{ t('map', 'shownLocations', { count: filteredComplaints.length }) }}</h3>
          </div>
          <div class="map-legend">
            <span class="legend-dot legend-dot--low"></span><span>{{ formatPriorityLabel('low') }}</span>
            <span class="legend-dot legend-dot--intermediate"></span><span>{{ formatPriorityLabel('intermediate') }}</span>
            <span class="legend-dot legend-dot--high"></span><span>{{ formatPriorityLabel('high') }}</span>
          </div>
        </div>

        <div v-if="loading" class="map-loading">
          <i class="fas fa-spinner fa-spin"></i>
          <span>{{ t('complaints', 'loadingMap') }}</span>
        </div>
        <div id="field-map" class="myview-map"></div>
      </div>

      <!-- Sidebar list -->
      <div class="map-sidebar">
        <div class="sidebar-list-header">
          <span class="eyebrow">{{ t('map', 'locations') }}</span>
          <span class="pill">{{ filteredComplaints.length }} {{ t('map', 'results') }}</span>
        </div>

        <div class="sidebar-list">
          <div
            v-for="item in filteredComplaints"
            :key="item.id"
            class="sidebar-list-item"
            :class="`prio-${item.priority}`"
            @click="focusMarker(item)"
          >
            <span class="prio-dot" :class="`prio-dot--${item.priority}`"></span>
            <div class="list-item-body">
              <span class="list-item-id">#{{ item.id }}</span>
              <p class="list-item-addr">{{ item.location_address || t('complaints', 'noAddress') }}</p>
            </div>
            <RouterLink
              :to="{ name: 'ReportDetails', params: { id: item.id } }"
              class="list-item-arrow"
              @click.stop
            >
              <i class="fas fa-arrow-right"></i>
            </RouterLink>
          </div>

          <div v-if="filteredComplaints.length === 0" class="sidebar-empty">
            <i class="fas fa-map-pin"></i>
            <p>{{ t('map', 'noComplaintsForPriority') }}</p>
          </div>
        </div>
      </div>

    </div>

  </div>
</template>

<script setup>
import { onMounted, ref, computed, watch } from 'vue'
import { useRouter } from 'vue-router'
import { complaintsApi } from '../api/complaints'
import { loadLeafletAssets } from '../utils/leafletLoader'
import { t, useLocale, formatPriorityLabel } from '../utils/i18n'

const router = useRouter()
const allComplaints = ref([])
const fetchError = ref('')
const loading = ref(false)
const activeFilter = ref('all')

const mapLoaded = ref(false)
const mapInstance = ref(null)
const markerLayer = ref(null)
// map from complaint id → leaflet marker
const markerMap = {}

// ── Priority colours ─────────────────────────────────
const PRIORITY_COLOR = {
  low:          '#27c840',
  intermediate: '#febc2f',
  high:         '#f04438',
}

const PRIORITY_DEFAULT = '#2f6fed'

function priorityColor(p) {
  return PRIORITY_COLOR[p] || PRIORITY_DEFAULT
}

function makeDivIcon(priority) {
  const color = priorityColor(priority)
  return window.L.divIcon({
    className: '',
    html: `<div style="
      width:14px;height:14px;
      border-radius:50%;
      background:${color};
      border:2.5px solid #fff;
      box-shadow:0 2px 8px rgba(0,0,0,.28);
    "></div>`,
    iconSize: [14, 14],
    iconAnchor: [7, 7],
  })
}

// ── Computed ─────────────────────────────────────────
const filteredComplaints = computed(() => {
  if (activeFilter.value === 'all') return allComplaints.value
  return allComplaints.value.filter(c => c.priority === activeFilter.value)
})

function countByPriority(p) {
  return allComplaints.value.filter(c => c.priority === p).length
}

// ── Filter ───────────────────────────────────────────
function setFilter(priority) {
  activeFilter.value = priority
}

watch(filteredComplaints, () => {
  updateMapMarkers()
})

// ── Map ──────────────────────────────────────────────
async function initMap() {
  if (mapLoaded.value) return

  try {
    await loadLeafletAssets()
  } catch {
    fetchError.value = t('complaints', 'unableLoadMap')
    return
  }

  mapInstance.value = window.L.map('field-map', {
    center: [31.44, 31.67],
    zoom: 12,
    scrollWheelZoom: false,
  })

  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors',
    maxZoom: 18,
  }).addTo(mapInstance.value)

  markerLayer.value = window.L.layerGroup().addTo(mapInstance.value)
  mapLoaded.value = true
  updateMapMarkers()
}

function updateMapMarkers() {
  if (!mapLoaded.value || !markerLayer.value) return

  markerLayer.value.clearLayers()
  Object.keys(markerMap).forEach(k => delete markerMap[k])

  const validMarkers = []

  filteredComplaints.value.forEach((item) => {
    const lat = parseFloat(item.latitude)
    const lng = parseFloat(item.longitude)
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return

    const marker = window.L.marker([lat, lng], { icon: makeDivIcon(item.priority) })

    marker.bindPopup(`
      <div style="min-width:180px;font-family:inherit;">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px;">
          <span style="
            display:inline-block;width:9px;height:9px;border-radius:50%;
            background:${priorityColor(item.priority)};flex-shrink:0;
          "></span>
          <strong style="font-size:.9rem;">#${item.id}</strong>
          <span style="
            margin-left:auto;font-size:.75rem;font-weight:600;
            padding:2px 8px;border-radius:999px;
            background:${priorityColor(item.priority)}22;
            color:${priorityColor(item.priority)};
          ">${formatPriorityLabel(item.priority)}</span>
        </div>
        <p style="margin:0 0 10px;font-size:.82rem;color:#667085;line-height:1.45;">
          ${item.location_address || t('complaints', 'noAddress')}
        </p>
        <a
          href="/reports/${item.id}"
          style="
            display:inline-flex;align-items:center;gap:6px;
            padding:6px 12px;border-radius:6px;
            background:#2f6fed;color:#fff;
            font-size:.8rem;font-weight:600;text-decoration:none;
          "
        >${t('complaints', 'openReport')} →</a>
      </div>
    `, { maxWidth: 240 })

    marker.addTo(markerLayer.value)
    markerMap[item.id] = marker
    validMarkers.push(marker)
  })

  if (validMarkers.length > 0) {
    const bounds = window.L.featureGroup(validMarkers).getBounds()
    mapInstance.value.fitBounds(bounds.pad(0.18), { maxZoom: 14 })
  }
}

function focusMarker(item) {
  const lat = parseFloat(item.latitude)
  const lng = parseFloat(item.longitude)
  if (!mapLoaded.value || !Number.isFinite(lat) || !Number.isFinite(lng)) return

  mapInstance.value.flyTo([lat, lng], 16, { duration: 0.8 })

  const marker = markerMap[item.id]
  if (marker) {
    setTimeout(() => marker.openPopup(), 850)
  }
}

// ── Fetch ─────────────────────────────────────────────
async function fetchMapData() {
  loading.value = true
  fetchError.value = ''

  try {
    const response = await complaintsApi.getMap()
    allComplaints.value = response.data.data || []
  } catch {
    fetchError.value = t('complaints', 'unableLoadLocations')
  } finally {
    loading.value = false
  }

  await initMap()
}

const currentLocale = useLocale()
watch(currentLocale, () => {
  updateMapMarkers()
})

onMounted(fetchMapData)
</script>

<style scoped>
/* ── Stats chips row ───────────────────────────────── */
.map-stats-row {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  width: 100%;
  max-width: 100%;
}

.map-stat-chip {
  flex: 1;
  min-width: 0;
  max-width: 100%;
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 16px 20px;
  border-radius: var(--radius-xl);
  background: var(--surface);
  border: 1px solid var(--line);
  box-shadow: var(--shadow-sm);
  cursor: pointer;
  transition:
    transform 200ms var(--ease-spring),
    box-shadow 200ms var(--ease-out),
    border-color 200ms var(--ease-out);
  user-select: none;
  overflow: hidden;
}

.map-stat-chip:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-md);
}

.map-stat-chip i {
  font-size: 1.3rem;
  flex-shrink: 0;
}

.map-stat-chip .chip-count {
  display: block;
  font-size: 1.6rem;
  font-weight: 800;
  line-height: 1;
}

.map-stat-chip .chip-label {
  display: block;
  font-size: 0.78rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  margin-top: 2px;
  opacity: 0.7;
}

/* per-priority accent colours */
.map-stat-chip--all i          { color: var(--primary); }
.map-stat-chip--all.active     { border-color: var(--primary); background: var(--primary-soft); }
.map-stat-chip--all.active i   { color: var(--primary-deep); }

.map-stat-chip--low i           { color: var(--success); }
.map-stat-chip--low.active      { border-color: var(--success); background: var(--success-soft); }

.map-stat-chip--intermediate i          { color: var(--warning); }
.map-stat-chip--intermediate.active     { border-color: var(--warning); background: var(--warning-soft); }

.map-stat-chip--high i          { color: var(--danger); }
.map-stat-chip--high.active     { border-color: var(--danger); background: var(--danger-soft); }

/* ── Map + sidebar layout ─────────────────────────── */
.map-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 320px;
  gap: 18px;
  align-items: start;
  width: 100%;
  overflow: hidden;
}

.map-card {
  min-height: 480px;
  min-width: 0;
  overflow: hidden;
}

/* ── Legend ───────────────────────────────────────── */
.map-legend {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 0.82rem;
  color: var(--text-soft);
  flex-wrap: wrap;
  min-width: 0;
}

.legend-dot {
  display: inline-block;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border: 2px solid #fff;
  box-shadow: 0 1px 4px rgba(0,0,0,.2);
  flex-shrink: 0;
}

.legend-dot--low          { background: #27c840; }
.legend-dot--intermediate { background: #febc2f; }
.legend-dot--high         { background: #f04438; }

/* ── Map loading ──────────────────────────────────── */
.map-loading {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 0;
  color: var(--text-soft);
  font-size: 0.9rem;
}

/* ── Sidebar list ─────────────────────────────────── */
.map-sidebar {
  display: flex;
  flex-direction: column;
  gap: 10px;
  min-width: 0;
  max-width: 100%;
}

.sidebar-list-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 2px;
  min-width: 0;
  flex-wrap: wrap;
  gap: 8px;
}

.sidebar-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  max-height: 560px;
  overflow-y: auto;
  overflow-x: hidden;
  padding-right: 4px;
  min-width: 0;
}

.sidebar-list::-webkit-scrollbar { width: 4px; }
.sidebar-list::-webkit-scrollbar-track { background: transparent; }
.sidebar-list::-webkit-scrollbar-thumb { background: var(--line); border-radius: 4px; }

.sidebar-list-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 14px;
  border-radius: var(--radius-lg);
  background: var(--surface);
  border: 1px solid var(--line);
  cursor: pointer;
  transition:
    transform 180ms var(--ease-spring),
    box-shadow 180ms var(--ease-out),
    border-color 180ms var(--ease-out);
  min-width: 0;
  max-width: 100%;
}

.sidebar-list-item:hover {
  transform: translateX(3px);
  box-shadow: var(--shadow-sm);
}

.sidebar-list-item.prio-high:hover        { border-color: rgba(240, 68, 56, 0.4); }
.sidebar-list-item.prio-intermediate:hover { border-color: rgba(254, 188, 47, 0.5); }
.sidebar-list-item.prio-low:hover         { border-color: rgba(39, 200, 64, 0.4); }

.prio-dot {
  flex-shrink: 0;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border: 2px solid #fff;
  box-shadow: 0 1px 4px rgba(0,0,0,.2);
}

.prio-dot--low          { background: #27c840; }
.prio-dot--intermediate { background: #febc2f; }
.prio-dot--high         { background: #f04438; }

.list-item-body {
  flex: 1;
  min-width: 0;
}

.list-item-id {
  font-size: 0.78rem;
  font-weight: 700;
  color: var(--text-soft);
}

.list-item-addr {
  margin: 2px 0 0;
  font-size: 0.82rem;
  color: var(--text);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.list-item-arrow {
  flex-shrink: 0;
  width: 28px;
  height: 28px;
  border-radius: var(--radius-sm);
  background: var(--primary-soft);
  color: var(--primary-deep);
  display: grid;
  place-items: center;
  font-size: 0.78rem;
  text-decoration: none;
  transition: background 160ms, transform 160ms var(--ease-spring);
}

.list-item-arrow:hover {
  background: var(--primary);
  color: #fff;
  transform: scale(1.08);
}

.sidebar-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 32px 20px;
  color: var(--text-soft);
  font-size: 0.9rem;
  text-align: center;
}

.sidebar-empty i {
  font-size: 1.6rem;
  opacity: 0.4;
}

/* ═══════════════════════════════════════════════════════════
   RESPONSIVE — scoped to this component
   ═══════════════════════════════════════════════════════════ */

/* ── 860px: Tablet — stack map and sidebar ────────────── */
@media (max-width: 860px) {
  .map-layout {
    grid-template-columns: 1fr;
    overflow: visible;
  }

  .map-card {
    min-height: 400px;
    order: 1;
    width: 100%;
  }

  .map-sidebar {
    order: 2;
    width: 100%;
  }
}

/* ── 768px: Small tablet ───────────────────────────────── */
@media (max-width: 768px) {
  .map-stats-row {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
    width: 100%;
  }

  .map-stat-chip {
    min-width: 0;
    max-width: 100%;
    flex: none;
    padding: 14px 16px;
  }

  .map-stat-chip i {
    font-size: 1.2rem;
  }

  .map-stat-chip .chip-count {
    font-size: 1.4rem;
  }

  .map-legend {
    flex-wrap: wrap;
    font-size: 0.78rem;
    gap: 6px;
    width: 100%;
  }

  .sidebar-list-header {
    flex-direction: row;
    flex-wrap: wrap;
    gap: 8px;
    width: 100%;
  }

  .sidebar-list {
    flex-direction: row;
    flex-wrap: wrap;
    max-height: none;
    overflow-y: visible;
    overflow-x: hidden;
    padding-right: 0;
    width: 100%;
  }

  .sidebar-list-item {
    flex: 1 1 calc(50% - 5px);
    min-width: 0;
    max-width: 100%;
  }

  .sidebar-list-item:hover {
    transform: translateY(-2px);
  }

  .map-card {
    min-height: 360px;
    width: 100%;
  }
}

/* ── 600px: Phablet ───────────────────────────────────── */
@media (max-width: 600px) {
  .map-stats-row {
    grid-template-columns: 1fr;
    gap: 8px;
    width: 100%;
  }

  .map-stat-chip {
    padding: 12px 14px;
    gap: 12px;
    width: 100%;
    max-width: 100%;
  }

  .map-stat-chip i {
    font-size: 1.15rem;
  }

  .map-stat-chip .chip-count {
    font-size: 1.35rem;
  }

  .map-stat-chip .chip-label {
    font-size: 0.75rem;
  }

  .sidebar-list {
    flex-direction: column;
    gap: 8px;
    width: 100%;
  }

  .sidebar-list-item {
    flex: 1 1 100%;
    width: 100%;
    max-width: 100%;
  }

  .sidebar-list-item:hover {
    transform: translateX(3px);
  }

  .map-card {
    min-height: 340px;
    width: 100%;
  }

  .map-loading {
    font-size: 0.86rem;
  }
}

/* ── 480px: Phone ──────────────────────────────────────── */
@media (max-width: 480px) {
  .map-stats-row {
    grid-template-columns: 1fr;
    gap: 8px;
  }

  .map-stat-chip {
    padding: 12px 14px;
    gap: 10px;
  }

  .map-stat-chip i {
    font-size: 1.1rem;
  }

  .map-stat-chip .chip-count {
    font-size: 1.3rem;
  }

  .map-stat-chip .chip-label {
    font-size: 0.72rem;
  }

  .map-legend {
    font-size: 0.76rem;
    gap: 5px;
  }

  .legend-dot {
    width: 9px;
    height: 9px;
  }

  .sidebar-list-header {
    padding: 0;
    flex-direction: column;
    align-items: flex-start;
  }

  .sidebar-list {
    gap: 8px;
    max-height: 400px;
    overflow-y: auto;
  }

  .sidebar-list-item {
    padding: 10px 12px;
    gap: 8px;
  }

  .list-item-id {
    font-size: 0.74rem;
  }

  .list-item-addr {
    font-size: 0.78rem;
  }

  .list-item-arrow {
    width: 26px;
    height: 26px;
    font-size: 0.74rem;
  }

  .prio-dot {
    width: 9px;
    height: 9px;
  }

  .sidebar-empty {
    padding: 24px 16px;
    font-size: 0.86rem;
  }

  .sidebar-empty i {
    font-size: 1.4rem;
  }

  .map-card {
    min-height: 320px;
  }

  .map-loading {
    padding: 10px 0;
    font-size: 0.82rem;
  }
}

/* ── 375px: Narrow phone (iPhone SE) ──────────────────── */
@media (max-width: 375px) {
  .map-stat-chip {
    padding: 11px 12px;
    gap: 9px;
  }

  .map-stat-chip i {
    font-size: 1.05rem;
  }

  .map-stat-chip .chip-count {
    font-size: 1.25rem;
  }

  .map-stat-chip .chip-label {
    font-size: 0.7rem;
  }

  .sidebar-list {
    max-height: 350px;
  }

  .sidebar-list-item {
    padding: 9px 10px;
    gap: 7px;
  }

  .list-item-arrow {
    width: 24px;
    height: 24px;
    font-size: 0.7rem;
  }

  .map-card {
    min-height: 300px;
  }
}

/* ── 360px: Very narrow phone ──────────────────────────── */
@media (max-width: 360px) {
  .map-stat-chip {
    padding: 10px 12px;
    gap: 8px;
  }

  .map-stat-chip i {
    font-size: 1rem;
  }

  .map-stat-chip .chip-count {
    font-size: 1.2rem;
  }

  .map-stat-chip .chip-label {
    font-size: 0.68rem;
  }

  .sidebar-list {
    max-height: 320px;
  }

  .map-card {
    min-height: 280px;
  }
}
</style>
