<template>
  <div class="news-details-view">
    <div class="topbar">
      <div class="page-intro">
      <span class="eyebrow"><i class="fas fa-newspaper"></i> {{ t('news', 'newsPage') }}</span>
      <h2 class="page-title">{{ newsItem ? newsItem.title : `News #${route.params.id}` }}</h2>
      <p class="page-subtitle">{{ t('news', 'viewEditDelete') }}</p>
    </div>

    <div class="topbar-actions">
      <RouterLink class="btn-secondary" :to="{ name: 'News' }">
        <i class="fas fa-arrow-left"></i>
        {{ t('common', 'back') }}
      </RouterLink>
    </div>
  </div>

  <div v-if="loading" class="empty-state">
    <h3>{{ t('news', 'loadingNewsItem') }}</h3>
  </div>

  <div v-else-if="fetchError" class="error-message">
    <i class="fas fa-circle-exclamation"></i>
    <span>{{ fetchError }}</span>
  </div>

  <template v-else-if="newsItem">
    <div class="hero-banner">
      <div>
        <span class="status-pill" :class="newsForm.is_active ? 'success' : 'warning'">
          {{ newsForm.is_active ? t('common', 'active') : t('common', 'inactive') }}
        </span>
        <h3 style="margin: 14px 0 8px;">{{ t('news', 'announcementPreview') }} #{{ newsItem.id }}</h3>
        <p class="muted-text" style="margin: 0;">{{ t('news', 'startsAndExpires', { start: formatDate(newsItem.start_date), end: formatDate(newsItem.expiry_date) }) }}</p>
      </div>
      <div class="hero-banner-tags">
        <span class="pill">{{ t('news', 'createdLabel', { date: formatDate(newsItem.created_at) }) }}</span>
      </div>
    </div>

    <div class="details-page-grid">
      <section class="detail-card">
        <div class="card-head">
          <div>
            <span class="eyebrow">{{ t('common', 'details') }}</span>
            <h3>{{ t('news', 'announcementPreview') }}</h3>
          </div>
        </div>

        <div class="detail-list">
          <div class="detail-row">
            <label>{{ t('common', 'title') }}</label>
            <span>{{ newsItem.title }}</span>
          </div>
          <div class="detail-row">
            <label>{{ t('common', 'body') }}</label>
            <span>{{ newsItem.body }}</span>
          </div>
          <div class="detail-row">
            <label>{{ t('common', 'image') }}</label>
            <div class="image-preview-cell">
              <img
                v-if="newsImageUrl"
                :src="newsImageUrl"
                :alt="newsItem.title || 'News image'"
                class="detail-image"
                @click="showImageViewer = true"
              />
              <span v-else>{{ t('news', 'noImageAttached') }}</span>
            </div>
          </div>
        </div>
      </section>

      <section class="detail-card">
        <div class="card-head">
          <div>
            <span class="eyebrow">{{ t('common', 'editSection') }}</span>
            <h3>{{ t('news', 'updateAnnouncement') }}</h3>
          </div>
        </div>

        <div v-if="formError" class="error-message">
          <i class="fas fa-circle-exclamation"></i>
          <span>{{ formError }}</span>
        </div>
        <div v-if="formSuccess" class="success-message">
          <i class="fas fa-circle-check"></i>
          <span>{{ formSuccess }}</span>
        </div>

        <form class="edit-form" @submit.prevent="updateNews">
          <div class="form-group">
            <label>{{ t('common', 'title') }}</label>
            <input v-model="newsForm.title" type="text" class="input" required />
          </div>

          <div class="form-group">
            <label>{{ t('common', 'body') }}</label>
            <textarea v-model="newsForm.body" rows="6"></textarea>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>{{ t('news', 'startDate') }}</label>
              <input v-model="newsForm.start_date" type="datetime-local" class="input" required />
            </div>
            <div class="form-group">
              <label>{{ t('news', 'expiryDate') }}</label>
              <input v-model="newsForm.expiry_date" type="datetime-local" class="input" required />
            </div>
          </div>

          <div class="form-group">
            <label>{{ t('common', 'image') }}</label>
            <input type="file" accept="image/*" @change="handleImageSelect" class="input" />
            <small v-if="newsForm.image">{{ t('news', 'selectedFile', { file: newsForm.image.name }) }}</small>
          </div>

          <div class="form-group toggle-row">
            <label>{{ t('common', 'active') }}</label>
            <input v-model="newsForm.is_active" type="checkbox" />
          </div>

          <div class="form-actions">
            <button type="submit" class="button-submit" :disabled="saving">
              {{ saving ? t('common', 'loading') : t('common', 'save') }}
            </button>
            <button type="button" class="btn-cancel" @click="resetForm">{{ t('common', 'reset') }}</button>
          </div>
        </form>
      </section>
    </div>

    <section class="detail-card">
      <div class="card-head">
        <div>
            <span class="eyebrow">{{ t('news', 'deleteSection') }}</span>
            <h3>{{ t('news', 'removeAnnouncement') }}</h3>
        </div>
      </div>

      <div v-if="deleteError" class="error-message">
        <i class="fas fa-circle-exclamation"></i>
        <span>{{ deleteError }}</span>
      </div>

      <div class="status-banner">
        <div>
          <strong>{{ t('news', 'deleteThisNews') }}</strong>
          <p class="muted-text" style="margin: 6px 0 0;">{{ t('news', 'deleteWarning') }}</p>
        </div>
        <div class="stack-actions">
          <button type="button" class="btn-danger" :disabled="deleting" @click="deleteNews">
            {{ deleting ? t('common', 'loading') : t('common', 'delete') }}
          </button>
        </div>
      </div>
    </section>
    <div
      v-if="showImageViewer"
      class="image-viewer-overlay"
      @click.self="showImageViewer = false"
    >
      <div class="image-viewer-content">
        <button type="button" class="image-viewer-close" @click="showImageViewer = false">
          ×
        </button>
        <img :src="newsImageUrl" :alt="newsItem.title || 'News image'" />
      </div>
    </div>
  </template>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { newsApi } from '../api/news'
import { normalizeMediaUrl } from '../utils/mediaHelper'
import { t } from '../utils/i18n'

const route = useRoute()
const router = useRouter()
const loading = ref(false)
const saving = ref(false)
const deleting = ref(false)
const newsItem = ref(null)
const fetchError = ref('')
const formError = ref('')
const formSuccess = ref('')
const deleteError = ref('')

const newsForm = ref({
  title: '',
  body: '',
  image: null,
  start_date: '',
  expiry_date: '',
  is_active: true,
})

const newsImageUrl = computed(() => normalizeMediaUrl(newsItem.value?.image))
const showImageViewer = ref(false)

function formatDate(value) {
  if (!value) return t('common', 'na')
  return new Date(value).toLocaleString()
}

function formatDateTime(dateString) {
  if (!dateString) return ''
  const date = new Date(dateString)
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000)
  return local.toISOString().slice(0, 16)
}

function parseError(error, fallback) {
  const errorData = error.response?.data
  if (typeof errorData === 'string') return errorData
  return errorData?.detail || errorData?.title?.[0] || errorData?.body?.[0] || fallback
}

function syncForm() {
  if (!newsItem.value) return
  newsForm.value = {
    title: newsItem.value.title || '',
    body: newsItem.value.body || '',
    image: null,
    start_date: formatDateTime(newsItem.value.start_date),
    expiry_date: formatDateTime(newsItem.value.expiry_date),
    is_active: !!newsItem.value.is_active,
  }
}

async function fetchNewsItem() {
  loading.value = true
  fetchError.value = ''

  try {
    const response = await newsApi.getById(route.params.id)
    newsItem.value = response.data.data || response.data
    syncForm()
  } catch (error) {
    fetchError.value = t('news', 'unableLoadNewsItem')
  } finally {
    loading.value = false
  }
}

function handleImageSelect(event) {
  const file = event.target.files[0]
  if (!file) return

  if (!file.type.startsWith('image/')) {
    formError.value = t('news', 'validImage')
    event.target.value = ''
    return
  }

  formError.value = ''
  newsForm.value.image = file
}

function resetForm() {
  formError.value = ''
  formSuccess.value = ''
  syncForm()
}

async function updateNews() {
  if (!newsItem.value) return

  saving.value = true
  formError.value = ''
  formSuccess.value = ''

  try {
    const body = {
      title: newsForm.value.title,
      body: newsForm.value.body,
      start_date: newsForm.value.start_date,
      expiry_date: newsForm.value.expiry_date,
      is_active: newsForm.value.is_active,
    }

    if (newsForm.value.image) {
      body.image = newsForm.value.image
    }

    await newsApi.update(newsItem.value.id, body)
    formSuccess.value = t('news', 'newsUpdated')
    await fetchNewsItem()
  } catch (error) {
    formError.value = parseError(error, t('news', 'failedUpdateNews'))
  } finally {
    saving.value = false
  }
}

async function deleteNews() {
  if (!newsItem.value) return

  deleting.value = true
  deleteError.value = ''

  try {
    await newsApi.delete(newsItem.value.id)
    await router.push({ name: 'News' })
  } catch (error) {
    deleteError.value = parseError(error, t('news', 'failedDeleteNews'))
  } finally {
    deleting.value = false
  }
}

onMounted(fetchNewsItem)
</script>
