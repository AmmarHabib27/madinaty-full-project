<template>
  <div class="categories-view">
    <div class="topbar">
      <div class="page-intro">
        <span class="eyebrow"><i class="fas fa-layer-group"></i> {{ t('categories', 'categorySetup') }}</span>
      <h2 class="page-title">{{ t('categories', 'createCategoriesHere') }}</h2>
      <p class="page-subtitle">{{ t('categories', 'listViewClean') }}</p>
    </div>

    <div class="topbar-actions">
      <button class="btn-reports" type="button" @click="showForm = !showForm">
        <i class="fas" :class="showForm ? 'fa-chevron-up' : 'fa-plus'"></i>
        {{ showForm ? t('categories', 'hideForm') : t('categories', 'addCategory') }}
      </button>
      <button class="btn-secondary" type="button" @click="fetchCategories(currentPage)" :disabled="loading">
        <i class="fas fa-rotate-right"></i>
        {{ t('common', 'refresh') }}
      </button>
    </div>
  </div>

  <div v-if="showForm" class="page-panel" style="margin-bottom: 18px;">
    <div class="card-head">
      <div>
        <span class="eyebrow">{{ t('categories', 'createMode') }}</span>
        <h3>{{ t('categories', 'createCategory') }}</h3>
      </div>
      <span class="pill">{{ t('categories', 'inlineCreate') }}</span>
    </div>

    <form class="category-form" @submit.prevent="createCategory">
      <div class="form-group">
        <label>{{ t('common', 'name') }}</label>
        <input v-model="categoryForm.name" type="text" class="input" :placeholder="t('categories', 'categoryNamePlaceholder')" required />
      </div>

      <div class="form-group toggle-row">
        <label>{{ t('common', 'active') }}</label>
        <input v-model="categoryForm.is_active" type="checkbox" />
      </div>

      <div v-if="formError" class="error-message">
        <i class="fas fa-circle-exclamation"></i>
        <span>{{ formError }}</span>
      </div>
      <div v-if="formSuccess" class="success-message">
        <i class="fas fa-circle-check"></i>
        <span>{{ formSuccess }}</span>
      </div>

      <div class="form-actions">
        <button type="submit" class="button-submit" :disabled="savingCategory">
          {{ savingCategory ? t('common', 'loading') : t('categories', 'createCategory') }}
        </button>
        <button type="button" class="btn-cancel" @click="cancelCreate">{{ t('common', 'clear') }}</button>
      </div>
    </form>
  </div>

  <div v-if="fetchError" class="error-message">
    <i class="fas fa-circle-exclamation"></i>
    <span>{{ fetchError }}</span>
  </div>

  <div class="table-shell">
    <div class="table-toolbar">
      <div class="card-head">
        <div>
          <h3 class="table-title">{{ t('categories', 'availableCategories') }}</h3>
          <p class="muted-text">{{ t('categories', 'openSingleCategory') }}</p>
        </div>
        <span class="pill">{{ t('complaints', 'visibleCount', { count: categories.length }) }}</span>
      </div>
    </div>

    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            <th>{{ t('common', 'id') }}</th>
            <th>{{ t('common', 'name') }}</th>
            <th>{{ t('common', 'active') }}</th>
            <th>{{ t('common', 'actions') }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="loading">
            <td colspan="4">{{ t('categories', 'loadingCategories') }}</td>
          </tr>
          <tr v-else-if="categories.length === 0">
            <td colspan="4">{{ t('categories', 'noCategories') }}</td>
          </tr>
          <tr v-for="item in categories" :key="item.id">
            <td data-label="ID">#{{ item.id }}</td>
            <td data-label="Name">{{ item.name }}</td>
            <td data-label="Active">
              <span class="status-pill" :class="item.is_active ? 'success' : 'warning'">
                {{ item.is_active ? t('common', 'active') : t('common', 'inactive') }}
              </span>
            </td>
            <td data-label="Actions">
              <div class="action-buttons">
                <RouterLink class="btn-view" :to="{ name: 'CategoryDetails', params: { id: item.id } }">{{ t('common', 'open') }}</RouterLink>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="pagination-controls" v-if="pagination.previous || pagination.next">
    <button class="btn-secondary" type="button" :disabled="!pagination.previous || loading" @click="changeCategoryPage(currentPage - 1)">
      {{ t('users', 'previous') }}
    </button>
    <span class="page-summary">{{ t('common', 'page') }} {{ currentPage }}</span>
    <button class="btn-secondary" type="button" :disabled="!pagination.next || loading" @click="changeCategoryPage(currentPage + 1)">
      {{ t('users', 'next') }}
    </button>
  </div>
</div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { categoriesApi } from '../api/categories'
import { t } from '../utils/i18n'

const showForm = ref(false)
const loading = ref(false)
const savingCategory = ref(false)
const categories = ref([])
const formError = ref('')
const formSuccess = ref('')
const fetchError = ref('')
const currentPage = ref(1)
const pagination = ref({})

const categoryForm = ref({
  name: '',
  is_active: true,
})

async function fetchCategories(page = 1) {
  loading.value = true
  fetchError.value = ''

  try {
    currentPage.value = page
    const response = await categoriesApi.getAll({ page })
    categories.value = response.data.data || response.data || []
    pagination.value = response.data.pagination || {}
  } catch (error) {
    fetchError.value = t('categories', 'unableLoadCategories')
  } finally {
    loading.value = false
  }
}

function changeCategoryPage(page) {
  if (page < 1) return
  fetchCategories(page)
}

function parseError(error, fallback) {
  const errorData = error.response?.data
  if (typeof errorData === 'string') return errorData
  return errorData?.detail || errorData?.name?.[0] || fallback
}

function resetForm() {
  categoryForm.value = {
    name: '',
    is_active: true,
  }
}

function cancelCreate() {
  showForm.value = false
  formError.value = ''
  formSuccess.value = ''
  resetForm()
}

async function createCategory() {
  formError.value = ''
  formSuccess.value = ''
  savingCategory.value = true

  try {
    const body = {
      name: categoryForm.value.name,
      is_active: categoryForm.value.is_active,
    }

    await categoriesApi.create(body)
    formSuccess.value = t('categories', 'categoryCreated')
    await fetchCategories(1)
    resetForm()
  } catch (error) {
    formError.value = parseError(error, t('categories', 'failedCreateCategory'))
  } finally {
    savingCategory.value = false
  }
}

onMounted(fetchCategories)
</script>
