let leafletLoadPromise = null

export function loadLeafletAssets() {
  if (window.L) return Promise.resolve()
  if (leafletLoadPromise) return leafletLoadPromise

  leafletLoadPromise = new Promise((resolve, reject) => {
    if (!document.querySelector('link[data-leaflet-css]')) {
      const css = document.createElement('link')
      css.rel = 'stylesheet'
      css.href = 'https://unpkg.com/leaflet/dist/leaflet.css'
      css.dataset.leafletCss = 'true'
      document.head.appendChild(css)
    }

    const script = document.createElement('script')
    script.src = 'https://unpkg.com/leaflet/dist/leaflet.js'
    script.onload = () => resolve()
    script.onerror = () => {
      leafletLoadPromise = null
      reject(new Error('Failed to load Leaflet'))
    }
    document.body.appendChild(script)
  })

  return leafletLoadPromise
}
