const apiBase = import.meta.env.VITE_API_BASE_URL || "";
export const DEFAULT_PROFILE_IMAGE = "/profile-placeholder.svg";

function getApiBase() {
  try {
    const url = new URL(apiBase || window.location.origin);
    url.hash = "";
    url.search = "";
    return url.href.replace(/\/+$/, "") + "/";
  } catch {
    return `${window.location.origin}/`;
  }
}

export function normalizeMediaUrl(value) {
  if (!value || typeof value !== "string") return "";

  const trimmed = value.trim();
  if (!trimmed) return "";

  if (/^https?:\/\//i.test(trimmed)) {
    return trimmed;
  }

  if (trimmed.startsWith("//")) {
    return `https:${trimmed}`;
  }

  try {
    return new URL(trimmed, getApiBase()).href;
  } catch {
    return trimmed;
  }
}
