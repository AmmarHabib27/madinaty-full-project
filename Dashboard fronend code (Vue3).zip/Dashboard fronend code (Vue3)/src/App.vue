<template>
  <RouterView v-if="isPublicRoute" v-slot="{ Component, route }">
    <Transition name="page-fade" mode="out-in">
      <component :is="Component" :key="route.fullPath" :is-dark-mode="isDarkMode" />
    </Transition>
  </RouterView>

  <div v-else class="app-layout">
    <Transition name="backdrop-fade">
      <div v-if="isSidebarOpen" class="app-backdrop" @click="closeSidebar"></div>
    </Transition>

    <AppSidebar :is-open="isSidebarOpen" :is-dark-mode="isDarkMode" @close="closeSidebar" />

    <div class="main">
      <AppNavbar
        :is-sidebar-open="isSidebarOpen"
        :is-dark-mode="isDarkMode"
        @toggle-sidebar="toggleSidebar"
        @toggle-theme="toggleTheme"
      />
      <div class="content-body">
        <RouterView v-slot="{ Component, route }">
          <Transition name="page-fade" mode="out-in">
            <component :is="Component" :key="route.fullPath" />
          </Transition>
        </RouterView>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import AppNavbar from './components/AppNavbar.vue'
import AppSidebar from './components/AppSidebar.vue'
import { useLocale } from './utils/i18n'

const route = useRoute()
const currentLocale = useLocale()
const THEME_STORAGE_KEY = 'madinaty-theme'
const isPublicRoute = computed(() => {
  // During initial load or if route is not matched, treat as public to avoid layout flickering/API calls
  if (!route.name) return true
  return route.meta.public === true
})
const isSidebarOpen = ref(false)
const isDarkMode = ref(false)

function toggleSidebar() {
  isSidebarOpen.value = !isSidebarOpen.value
}

function closeSidebar() {
  isSidebarOpen.value = false
}

function applyTheme() {
  document.documentElement.setAttribute('data-theme', isDarkMode.value ? 'dark' : 'light')
}

function applyDirection() {
  document.documentElement.dir = currentLocale.value === 'ar' ? 'rtl' : 'ltr'
  document.documentElement.lang = currentLocale.value || 'en'
}

function toggleTheme() {
  isDarkMode.value = !isDarkMode.value
}

onMounted(() => {
  const savedTheme = localStorage.getItem(THEME_STORAGE_KEY)
  const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches

  isDarkMode.value = savedTheme ? savedTheme === 'dark' : Boolean(prefersDark)
  applyTheme()
  applyDirection()
})

watch(isDarkMode, (enabled) => {
  applyTheme()
  localStorage.setItem(THEME_STORAGE_KEY, enabled ? 'dark' : 'light')
})

watch(currentLocale, () => {
  applyDirection()
})

watch(
  () => route.fullPath,
  () => {
    closeSidebar()
  },
)
</script>
