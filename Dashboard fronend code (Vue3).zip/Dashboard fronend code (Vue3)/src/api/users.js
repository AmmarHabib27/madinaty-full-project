import api from "./axios";

export const usersApi = {
  getAll: async (params) => {
    const response = await api.get("/users/", { params });
    return response;
  },
};
