import api from "./axios";

export const authApi = {
  login: async (body) => {
    const response = await api.post("/auth/login/", body);
    return response;
  },

  logout: async (refresh) => {
    const response = await api.post("/auth/logout/", { refresh });
    return response;
  },

  changePassword: async (body) => {
    const response = await api.post("/auth/change-password/", body);
    return response;
  },
};
