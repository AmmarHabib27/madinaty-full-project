import api from "./axios";

export const newsApi = {
  getAll: async (params) => {
    const response = await api.get("/news/", { params });
    return response;
  },

  getById: async (id) => {
    const response = await api.get(`/news/${id}/`);
    return response;
  },

  create: async (body) => {
    let response;
    if (body.image instanceof File) {
      const form = new FormData();
      Object.entries(body).forEach(([key, val]) => {
        if (val !== null && val !== undefined) form.append(key, val);
      });
      response = await api.post("/news/", form, {
        headers: { "Content-Type": "multipart/form-data" },
      });
    } else {
      response = await api.post("/news/", body);
    }
    return response;
  },

  update: async (id, body) => {
    let response;
    if (body.image instanceof File) {
      const form = new FormData();
      Object.entries(body).forEach(([key, val]) => {
        if (val !== null && val !== undefined) form.append(key, val);
      });
      response = await api.patch(`/news/${id}/`, form, {
        headers: { "Content-Type": "multipart/form-data" },
      });
    } else {
      response = await api.patch(`/news/${id}/`, body);
    }
    return response;
  },

  delete: async (id) => {
    const response = await api.delete(`/news/${id}/`);
    return response;
  },
};
