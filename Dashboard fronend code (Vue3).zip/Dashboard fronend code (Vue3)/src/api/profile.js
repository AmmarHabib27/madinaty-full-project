import api from "./axios";

export const profileApi = {
  get: async () => {
    const response = await api.get("/profile/");
    return response;
  },

  update: async (body) => {
    if (body.profile_picture instanceof File) {
      const form = new FormData();
      Object.entries(body).forEach(([key, val]) => {
        if (val !== null && val !== undefined) form.append(key, val);
      });
      const response = await api.patch("/profile/", form, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      return response;
    }
    const response = await api.patch("/profile/", body);
    return response;
  },
};
