import api from "./axios";

export const categoriesApi = {
  getAll: async (params) => {
    const response = await api.get("/categories/", { params });
    return response;
  },

  getById: async (id) => {
    const response = await api.get(`/categories/${id}/`);
    return response;
  },

  create: async (body) => {
    const response = await api.post("/categories/", body);
    return response;
  },

  update: async (id, body) => {
    const response = await api.patch(`/categories/${id}/`, body);
    return response;
  },
};
