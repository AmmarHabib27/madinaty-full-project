import api from "./axios";

export const complaintsApi = {
  getAll: async (params) => {
    const response = await api.get("/complaints/", { params });
    return response;
  },

  getMap: async () => {
    const response = await api.get("/complaints/map");
    return response;
  },

  getById: async (id) => {
    const response = await api.get(`/complaints/${id}/`);
    return response;
  },

  update: async (id, body) => {
    const response = await api.patch(`/complaints/${id}/`, body);
    return response;
  },
};
