import { createRouter, createWebHistory } from "vue-router";

const DashboardView = () => import("../views/DashboardView.vue");
const ReportsView = () => import("../views/ReportsView.vue");
const NewsView = () => import("../views/NewsView.vue");
const CategoriesView = () => import("../views/CategoriesView.vue");
const MyViewView = () => import("../views/MyViewView.vue");
const UsersView = () => import("../views/UsersView.vue");
const SettingsView = () => import("../views/SettingsView.vue");
const ReportDetailsView = () => import("../views/ReportDetailsView.vue");
const NewsDetailsView = () => import("../views/NewsDetailsView.vue");
const CategoryDetailsView = () => import("../views/CategoryDetailsView.vue");
const LoginView = () => import("../views/LoginView.vue");

const routes = [
  {
    path: "/login",
    name: "Login",
    component: LoginView,
    meta: { public: true },
  },
  { path: "/", name: "Dashboard", component: DashboardView },
  { path: "/reports", name: "Reports", component: ReportsView },
  {
    path: "/reports/:id",
    name: "ReportDetails",
    component: ReportDetailsView,
  },
  { path: "/news", name: "News", component: NewsView },
  {
    path: "/news/:id",
    name: "NewsDetails",
    component: NewsDetailsView,
  },
  { path: "/categories", name: "Categories", component: CategoriesView },
  {
    path: "/categories/:id",
    name: "CategoryDetails",
    component: CategoryDetailsView,
  },
  { path: "/myview", name: "MyView", component: MyViewView },
  { path: "/users", name: "Users", component: UsersView },
  { path: "/settings", name: "Settings", component: SettingsView },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to) => {
  const token = localStorage.getItem("access");
  const isAuth = !!token && token !== 'undefined' && token !== 'null';

  if (!to.meta.public && !isAuth) {
    return { name: "Login" };
  }
  
  if (to.name === "Login" && isAuth) {
    return { name: "Dashboard" };
  }
});

export default router;
