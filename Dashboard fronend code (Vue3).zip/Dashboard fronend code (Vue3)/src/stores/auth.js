import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { authApi } from '../api/auth'

export const useAuthStore = defineStore('auth', () => {
  const access = ref(localStorage.getItem('access') || null)
  const refresh = ref(localStorage.getItem('refresh') || null)

  const isLoggedIn = computed(() => !!access.value && access.value !== 'undefined' && access.value !== 'null')

  async function login(phone, password) {
    const res = await authApi.login({ phone, password })
    access.value = res.data.data.access
    refresh.value = res.data.data.refresh
    localStorage.setItem('access', access.value)
    localStorage.setItem('refresh', refresh.value)
    return res.data
  }

  async function logout() {
    try {
      if (refresh.value) await authApi.logout(refresh.value)
    } finally {
      access.value = null
      refresh.value = null
      localStorage.removeItem('access')
      localStorage.removeItem('refresh')
    }
  }

  async function changePassword(old_password, new_password, confirm_password) {
    const res = await authApi.changePassword({ old_password, new_password, confirm_password })
    return res.data
  }

  return { access, refresh, isLoggedIn, login, logout, changePassword }
})
