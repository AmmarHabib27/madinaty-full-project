import { defineStore } from 'pinia'
import { complaintsApi } from '../api/complaints'

function extractList(payload) {
  if (Array.isArray(payload?.data)) return payload.data
  if (Array.isArray(payload)) return payload
  if (Array.isArray(payload?.results)) return payload.results
  return []
}

function extractCount(payload) {
  return payload?.pagination?.count ?? payload?.count ?? extractList(payload).length
}

export const useReportsStore = defineStore('reports', {
  state: () => ({
    stats: {
      new: 0,
      solved: 0,
      cancelled: 0,
      latest: 0,
    },
    reports: [],
    filter: { status: '', category: '', area: '', date: '' },
    loadingStats: false,
    statsError: '',
  }),
  getters: {
    filteredReports: (state) => {
      return state.reports.filter(r => {
        if (state.filter.status && r.status.toLowerCase() !== state.filter.status) return false
        if (state.filter.category && r.category.toLowerCase() !== state.filter.category) return false
        return true
      })
    },
  },
  actions: {
    applyFilter(filter) {
      this.filter = { ...filter }
    },
    async fetchDashboardStats() {
      this.loadingStats = true
      this.statsError = ''

      try {
        const [newReports, solvedReports, cancelledReports, allReports] = await Promise.all([
          complaintsApi.getAll({ status: 'placed', page: 1 }),
          complaintsApi.getAll({ status: 'resolved', page: 1 }),
          complaintsApi.getAll({ status: 'rejected', page: 1 }),
          complaintsApi.getAll({ page: 1 }),
        ])

        this.stats = {
          new: extractCount(newReports.data),
          solved: extractCount(solvedReports.data),
          cancelled: extractCount(cancelledReports.data),
          latest: extractCount(allReports.data),
        }
      } catch (error) {
        this.statsError = 'Dashboard stats are unavailable right now.'
      } finally {
        this.loadingStats = false
      }
    },
  },
})
