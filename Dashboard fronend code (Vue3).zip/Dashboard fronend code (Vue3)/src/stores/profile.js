import { defineStore } from "pinia";
import { ref, computed } from "vue";
import { profileApi } from "../api/profile";
import { DEFAULT_PROFILE_IMAGE, normalizeMediaUrl } from "../utils/mediaHelper";

export const useProfileStore = defineStore("profile", () => {
  const profile = ref(null);
  const loading = ref(false);
  const error = ref(null);

  let profileRequest = null;

  const profileImage = computed(() => {
    return normalizeMediaUrl(profile.value?.profile_picture) || DEFAULT_PROFILE_IMAGE;
  });

  async function fetchProfile({ force = false } = {}) {
    if (profile.value && !force) return profile.value;
    if (profileRequest && !force) return profileRequest;

    loading.value = true;
    error.value = null;
    profileRequest = (async () => {
      const response = await profileApi.get();
      profile.value = response.data.data || response.data;
      return profile.value;
    })();

    try {
      return await profileRequest;
    } catch (err) {
      error.value = err;
      throw err;
    } finally {
      loading.value = false;
      profileRequest = null;
    }
  }

  async function updateProfile(body) {
    loading.value = true;
    error.value = null;
    try {
      const response = await profileApi.update(body);
      profile.value = response.data.data || response.data;
      return response;
    } catch (err) {
      error.value = err;
      throw err;
    } finally {
      loading.value = false;
    }
  }

  return {
    profile,
    loading,
    error,
    profileImage,
    fetchProfile,
    updateProfile,
  };
});
