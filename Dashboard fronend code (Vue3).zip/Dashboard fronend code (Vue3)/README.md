# Madinaty Management System

Admin dashboard for managing complaints, news, categories, users, profile settings, and map-based report context.

## Setup

```bash
npm install
npm run dev
```

Create `.env` from `.env.example` and set `VITE_API_BASE_URL` to the admin API base URL.

## Production Build

```bash
npm run build
```
